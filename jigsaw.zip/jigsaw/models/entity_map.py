from odoo import models, fields, api, _
from odoo.exceptions import UserError
import json
import mimetypes
import re
from urllib import request, error

class JigsawEntity(models.Model):
    _name = 'jigsaw.entity'
    _description = 'Jigsaw Entity'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', required=True, tracking=True)
    entity_id_external = fields.Char(string='Entity ID')
    type = fields.Selection([
        ('individual', 'Individual'),
        ('company', 'Company'),
        ('trust', 'Trust'),
        ('fund', 'Fund'),
        ('gov', 'Government Entity'),
        ('org_unit', 'Organization Unit'),
        ('asset', 'Asset'),
        ('account', 'Account'),
        ('legal_case', 'Legal Case'),
        ('event', 'Event')
    ], string='Type', default='company', required=True)
    
    subtype = fields.Selection([
        ('listed', 'Listed Company'),
        ('private', 'Private Company'),
        ('llc', 'LLC'),
        ('partnership', 'Partnership'),
        ('spv', 'Special Purpose Vehicle')
    ], string='Subtype')

    jurisdiction = fields.Char(string='Jurisdiction', help="e.g. Delaware, British Columbia")
    registration_no = fields.Char(string='Registration No')
    partner_id = fields.Many2one('res.partner', string='Related Partner')
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
    currency_id = fields.Many2one(
        'res.currency',
        string='Currency',
        default=lambda self: self.env.company.currency_id,
    )
    country_id = fields.Many2one('res.country', string='Country')
    avatar = fields.Binary(string='Avatar/Logo')
    
    # New Properties from UI
    commitment_amount = fields.Float(string='Commitment Amount')
    capital_contributed = fields.Float(string='Capital Contributed')
    tax_id_number = fields.Char(string='Tax ID Number')
    registered_office = fields.Text(string='Registered Office')
    formation_date = fields.Date(string='Formation / Incorporation Date')
    fund_family_name = fields.Char(string='Fund Family')
    directors = fields.Char(string='Directors')
    officers = fields.Char(string='Officers')
    authorised_signatory = fields.Char(string='Authorised Signatory')
    region = fields.Char(string='Region')
    tax_filing_deadline = fields.Date(string='Tax Filing Deadline')
    
    diagram_id = fields.Many2one('jigsaw.diagram', string='Diagram')
    
    relation_ids = fields.One2many('jigsaw.relation', 'source_entity_id', string='Outgoing Relationships')
    target_relation_ids = fields.One2many('jigsaw.relation', 'target_entity_id', string='Incoming Relationships')

    # ──────────────────────────────────────────────────────────────────────
    # Entity Basics (PE / VC oriented)
    # ──────────────────────────────────────────────────────────────────────
    pe_entity_type = fields.Selection([
        ('portfolio_co', 'Portfolio Co'),
        ('spv', 'SPV'),
        ('fund_entity', 'Fund'),
        ('gp', 'GP'),
        ('lp', 'LP'),
        ('subsidiary', 'Subsidiary'),
    ], string='PE Entity Type')
    pe_jurisdiction = fields.Selection([
        ('india', 'India'),
        ('singapore', 'Singapore'),
        ('delaware', 'Delaware'),
        ('other', 'Other'),
    ], string='PE Jurisdiction')
    pe_industry = fields.Selection([
        ('saas', 'SaaS'),
        ('fintech', 'Fintech'),
        ('healthtech', 'Healthtech'),
        ('edtech', 'Edtech'),
        ('ecommerce', 'E-commerce'),
        ('manufacturing', 'Manufacturing'),
        ('other', 'Other'),
    ], string='Industry / Sector')
    pe_stage = fields.Selection([
        ('seed', 'Seed'),
        ('series_a', 'Series A'),
        ('series_b', 'Series B'),
        ('growth', 'Growth'),
        ('pre_ipo', 'Pre-IPO'),
    ], string='Stage')
    pe_status = fields.Selection([
        ('active', 'Active'),
        ('exited', 'Exited'),
        ('winding_up', 'Winding Up'),
        ('dormant', 'Dormant'),
    ], string='Status', default='active')

    # ──────────────────────────────────────────────────────────────────────
    # Investment & Ownership
    # ──────────────────────────────────────────────────────────────────────
    investment_date = fields.Date(string='Investment Date')
    investment_round = fields.Selection([
        ('seed', 'Seed'),
        ('series_a', 'Series A'),
        ('series_b', 'Series B'),
        ('bridge', 'Bridge'),
    ], string='Investment Round')
    ownership_pct_overall = fields.Float(string='Ownership %')
    amount_invested = fields.Monetary(string='Amount Invested', currency_field='currency_id')
    valuation_current = fields.Monetary(string='Current Valuation', currency_field='currency_id')
    valuation_last = fields.Monetary(string='Last Valuation', currency_field='currency_id')
    performance_irr = fields.Float(string='IRR %')
    performance_moic = fields.Float(string='MOIC (x)')
    investor_type = fields.Selection([
        ('lead', 'Lead'),
        ('co_investor', 'Co-investor'),
    ], string='Investor Type')
    spv_linked = fields.Boolean(string='SPV Linked')

    # ──────────────────────────────────────────────────────────────────────
    # Portfolio Performance
    # ──────────────────────────────────────────────────────────────────────
    revenue_band = fields.Selection([
        ('lt_1m', '< $1M'),
        ('1m_10m', '$1M – $10M'),
        ('gt_10m', '$10M+'),
    ], string='Revenue Band')
    burn_rate = fields.Monetary(string='Monthly Burn Rate', currency_field='currency_id')
    runway_months = fields.Integer(string='Runway (months)')
    profitability = fields.Selection([
        ('profitable', 'Profitable'),
        ('loss_making', 'Loss-making'),
    ], string='Profitability')
    high_growth_flag = fields.Boolean(string='High Growth')
    exit_pipeline = fields.Selection([
        ('exit_12m', 'Exit in 12 months'),
        ('exit_24m', 'Exit in 24 months'),
        ('none', 'No active pipeline'),
    ], string='Exit Pipeline')

    # ──────────────────────────────────────────────────────────────────────
    # Compliance & Governance
    # ──────────────────────────────────────────────────────────────────────
    compliance_status = fields.Selection([
        ('green', 'Green'),
        ('amber', 'Amber'),
        ('red', 'Red'),
    ], string='Compliance Status')
    board_meetings = fields.Boolean(string='Board Meetings Held')
    board_meeting_frequency = fields.Selection([
        ('monthly', 'Monthly'),
        ('quarterly', 'Quarterly'),
        ('annually', 'Annually'),
    ], string='Board Meeting Frequency')
    financial_filings = fields.Boolean(string='Financial Filings Up To Date')
    roc_sec_status = fields.Selection([
        ('filed', 'Filed'),
        ('pending', 'Pending'),
    ], string='ROC / SEC Status')
    kyc_aml = fields.Selection([
        ('complete', 'Complete'),
        ('pending', 'Pending'),
    ], string='KYC / AML')
    document_completeness = fields.Selection([
        ('complete', 'Complete'),
        ('partial', 'Partial'),
        ('missing', 'Missing'),
    ], string='Document Completeness')
    regulatory_flag_fema = fields.Boolean(string='FEMA Flag')
    regulatory_flag_odi = fields.Boolean(string='ODI Flag')
    regulatory_flag_fdi = fields.Boolean(string='FDI Flag')

    # ──────────────────────────────────────────────────────────────────────
    # Cap Table & Securities
    # ──────────────────────────────────────────────────────────────────────
    share_class = fields.Selection([
        ('equity', 'Equity'),
        ('preference', 'Preference'),
        ('safe', 'SAFE'),
    ], string='Share Class')
    esop_pct = fields.Float(string='ESOP %')
    last_round_dilution = fields.Float(string='Last Round Dilution %')
    liquidation_preference = fields.Selection([
        ('1x', '1x'),
        ('2x', '2x'),
        ('3x', '3x'),
        ('participating', 'Participating'),
        ('non_participating', 'Non-Participating'),
    ], string='Liquidation Preference')
    anti_dilution = fields.Boolean(string='Anti-dilution')

    # ──────────────────────────────────────────────────────────────────────
    # Stakeholders
    # ──────────────────────────────────────────────────────────────────────
    board_seat = fields.Boolean(string='Board Seat')
    observer_rights = fields.Boolean(string='Observer Rights')
    founder_status = fields.Selection([
        ('active', 'Active'),
        ('exited', 'Exited'),
    ], string='Founder Status')
    management_changes = fields.Boolean(string='Management Changes')
    co_investors = fields.Boolean(string='Co-investors Present')

    # ──────────────────────────────────────────────────────────────────────
    # Timeline
    # ──────────────────────────────────────────────────────────────────────
    next_board_meeting = fields.Date(string='Next Board Meeting')
    last_valuation_date = fields.Date(string='Last Valuation Date')
    exit_timeline_estimate = fields.Char(string='Exit Timeline Estimate')
    milestones = fields.Text(string='Milestones')

    # ──────────────────────────────────────────────────────────────────────
    # Documents
    # ──────────────────────────────────────────────────────────────────────
    documents_uploaded = fields.Selection([
        ('complete', 'Complete'),
        ('partial', 'Partial'),
        ('missing', 'Missing'),
    ], string='Documents Uploaded')
    latest_financials = fields.Boolean(string='Latest Financials Available')
    sha_ssa = fields.Selection([
        ('signed', 'Signed'),
        ('not_signed', 'Not Signed'),
    ], string='SHA / SSA')
    due_diligence = fields.Selection([
        ('pending', 'Pending'),
        ('completed', 'Completed'),
    ], string='Due Diligence')

    # ──────────────────────────────────────────────────────────────────────
    # Fund Structuring
    # ──────────────────────────────────────────────────────────────────────
    fund_name = fields.Char(string='Fund Name')
    gp_lp_mapping = fields.Boolean(string='GP / LP Mapping')
    co_investment = fields.Boolean(string='Co-investment')
    spv_vs_direct = fields.Selection([
        ('spv', 'SPV'),
        ('direct', 'Direct'),
    ], string='SPV vs Direct')
    cross_holdings = fields.Boolean(string='Cross Holdings')

    # ──────────────────────────────────────────────────────────────────────
    # Risk & Alerts
    # ──────────────────────────────────────────────────────────────────────
    risk_high_burn = fields.Boolean(string='High Burn Flag')
    risk_down_round = fields.Boolean(string='Down Round Risk')
    risk_founder_dispute = fields.Boolean(string='Founder Dispute')
    risk_compliance_breach = fields.Boolean(string='Compliance Breach')
    risk_regulatory_exposure = fields.Boolean(string='Regulatory Exposure')

    # ──────────────────────────────────────────────────────────────────────
    # Tags
    # ──────────────────────────────────────────────────────────────────────
    tag_top_10 = fields.Boolean(string='Top 10 Bets')
    tag_followon_priority = fields.Boolean(string='Follow-on Priority')
    tag_under_watch = fields.Boolean(string='Under Watch')
    tag_exit_ready = fields.Boolean(string='Exit Ready')
    tag_strategic_focus = fields.Boolean(string='Strategic Focus')

    document_ids = fields.One2many(
        'jigsaw.entity.document',
        'entity_id',
        string='Uploaded documents',
    )

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        for record in records:
            if record.diagram_id:
                record.diagram_id.entity_ids = [(4, record.id)]
        return records

class JigsawEntityDocument(models.Model):
    _name = 'jigsaw.entity.document'
    _description = 'Entity uploaded document'
    _order = 'create_date desc'

    name = fields.Char(string='Title', required=True)
    entity_id = fields.Many2one(
        'jigsaw.entity',
        string='Entity',
        required=True,
        ondelete='cascade',
        index=True,
    )
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        default=lambda self: self.env.company,
    )
    file = fields.Binary(string='File', required=True, attachment=True)
    file_name = fields.Char(string='Filename')

class JigsawRelation(models.Model):
    _name = 'jigsaw.relation'
    _description = 'Jigsaw Relation'

    source_entity_id = fields.Many2one('jigsaw.entity', string='Source Entity', required=True, ondelete='cascade')
    target_entity_id = fields.Many2one('jigsaw.entity', string='Target Entity', required=True, ondelete='cascade')
    
    ownership_pct = fields.Float(string='Ownership %', default=0.0)
    control_pct = fields.Float(string='Control %', default=0.0)
    
    relationship_type = fields.Selection([
        ('owns', 'OWNS'),
        ('controls', 'CONTROLS'),
        ('director', 'DIRECTOR_OF'),
        ('beneficiary', 'BENEFICIARY_OF'),
        ('trustee', 'TRUSTEE_OF'),
        ('reports', 'REPORTS_TO'),
        ('transferred', 'TRANSFERRED_TO'),
        ('guarantees', 'GUARANTEES'),
        ('partner', 'PARTNER_IN'),
        ('litigates', 'LITIGATES_AGAINST')
    ], string='Relation Type', default='owns')
    
    effective_from = fields.Date(string='Effective From')
    effective_to = fields.Date(string='Effective To')
    amount = fields.Monetary(string='Amount')
    currency_id = fields.Many2one('res.currency', string='Currency', default=lambda self: self.env.company.currency_id)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
    
    description = fields.Char(string='Description')

class JigsawDiagram(models.Model):
    _name = 'jigsaw.diagram'
    _description = 'Jigsaw Structure Diagram'
    
    name = fields.Char(string='Diagram Name', required=True)
    description = fields.Text(string='Description')
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
    
    # Store layout as JSON: { "entity_id": { "x": 100, "y": 200 }, ... }
    layout_data = fields.Text(string='Layout Data', default='{}')
    
    entity_ids = fields.Many2many('jigsaw.entity', string='Entities')
    ai_source_image = fields.Binary(string='AI Source Image', attachment=True)
    ai_source_image_filename = fields.Char(string='AI Source Filename')
    ai_ocr_text = fields.Text(string='OCR Extracted Text')
    
    def action_open_workshop(self):
        return {
            'type': 'ir.actions.client',
            'tag': 'jigsaw.workshop',
            'params': {
                'diagram_id': self.id,
            },
            'context': {
                'default_diagram_id': self.id,
                'active_id': self.id,
                'active_model': 'jigsaw.diagram',
            },
            'target': 'current',
        }

    def get_formview_action(self, access_uid=None):
        """Redirect "open record" actions (kanban card click, list row click,
        breadcrumbs, etc.) straight into the PurpleMaps visualizer instead of
        opening the plain form view.
        """
        self.ensure_one()
        return self.action_open_workshop()

    def _extract_json_from_gemini_text(self, text):
        cleaned = (text or '').strip()
        if cleaned.startswith('```'):
            match = re.search(r'```(?:json)?\s*(.*?)```', cleaned, re.DOTALL | re.IGNORECASE)
            if match:
                cleaned = match.group(1).strip()
        return json.loads(cleaned)

    def _normalize_gemini_model_name(self, model_name):
        model = (model_name or '').strip()
        if model.startswith('models/'):
            model = model.split('/', 1)[1]
        return model

    def _list_supported_gemini_models(self, api_key):
        url = "https://generativelanguage.googleapis.com/v1beta/models?key=%s" % api_key
        req = request.Request(url=url, headers={"Content-Type": "application/json"}, method="GET")
        try:
            with request.urlopen(req, timeout=30) as response:
                body = response.read().decode('utf-8')
        except Exception:
            return []

        data = json.loads(body or '{}')
        supported = []
        for model in data.get('models', []):
            methods = model.get('supportedGenerationMethods') or []
            if 'generateContent' not in methods:
                continue
            name = self._normalize_gemini_model_name(model.get('name'))
            if name:
                supported.append(name)
        return supported

    def _map_entity_type(self, entity_type):
        allowed = {
            'individual', 'company', 'trust', 'fund', 'gov',
            'org_unit', 'asset', 'account', 'legal_case', 'event',
        }
        value = (entity_type or '').strip().lower()
        return value if value in allowed else 'company'

    def _map_relation_type(self, relation_type):
        allowed = {
            'owns', 'controls', 'director', 'beneficiary', 'trustee',
            'reports', 'transferred', 'guarantees', 'partner', 'litigates',
        }
        value = (relation_type or '').strip().lower()
        return value if value in allowed else 'owns'

    def _parse_ownership_pct(self, raw_value):
        if raw_value in (None, False, ''):
            return 0.0
        if isinstance(raw_value, (int, float)):
            return float(raw_value)
        cleaned = str(raw_value).strip().replace('%', '')
        match = re.search(r'-?\d+(?:\.\d+)?', cleaned)
        if not match:
            return 0.0
        return float(match.group(0))

    def _call_gemini_entity_extraction(self, image_b64, filename):
        ir_config = self.env['ir.config_parameter'].sudo()
        api_key = (ir_config.get_param('jigsaw.gemini_api_key') or '').strip()
        requested_model = self._normalize_gemini_model_name(
            ir_config.get_param('jigsaw.gemini_model') or ''
        ) or 'gemini-2.0-flash'
        if not api_key:
            raise UserError(_('Please set Gemini API Key in PurpleMaps settings.'))

        supported_models = self._list_supported_gemini_models(api_key)
        model = requested_model
        if supported_models and requested_model not in supported_models:
            preferred = [
                'gemini-2.5-flash',
                'gemini-2.0-flash',
                'gemini-1.5-flash-latest',
                'gemini-1.5-flash',
            ]
            fallback = next((m for m in preferred if m in supported_models), supported_models[0])
            model = fallback

        mime_type = mimetypes.guess_type(filename or '')[0] or 'image/png'
        prompt = (
            "Read this ownership/entity map image and return STRICT JSON only.\n"
            "Preserve the visual structure from the image.\n"
            "Schema:\n"
            "{\n"
            "  \"entities\": [\n"
            "    {\"name\": \"...\", \"type\": \"company|individual|trust|fund|gov|org_unit|asset|account|legal_case|event\", "
            "\"x\": number, \"y\": number}\n"
            "  ],\n"
            "  \"relations\": [{\"source\": \"entity name\", \"target\": \"entity name\", \"relationship_type\": "
            "\"owns|controls|director|beneficiary|trustee|reports|transferred|guarantees|partner|litigates\", "
            "\"ownership_pct\": 0-100}]\n"
            "}\n"
            "Every relation must include ownership_pct mapped to that exact line in the image. "
            "Use the exact entity names from the image and keep relative positions consistent."
        )
        payload = {
            "contents": [{
                "parts": [
                    {"text": prompt},
                    {"inline_data": {"mime_type": mime_type, "data": image_b64}},
                ]
            }]
        }
        url = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s" % (model, api_key)
        req = request.Request(
            url=url,
            data=json.dumps(payload).encode('utf-8'),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with request.urlopen(req, timeout=60) as response:
                body = response.read().decode('utf-8')
        except error.HTTPError as exc:
            err_body = exc.read().decode('utf-8', errors='ignore')
            raise UserError(
                _("Gemini API request failed for model '%s': %s") % (model, err_body)
            ) from exc
        except Exception as exc:
            raise UserError(_("Could not connect to Gemini: %s") % str(exc)) from exc

        data = json.loads(body or '{}')
        candidates = data.get('candidates') or []
        if not candidates:
            raise UserError(_('Gemini did not return any candidates.'))
        parts = (candidates[0].get('content') or {}).get('parts') or []
        text = ''.join(part.get('text', '') for part in parts if isinstance(part, dict))
        if not text:
            raise UserError(_('Gemini response did not include text output.'))
        try:
            return self._extract_json_from_gemini_text(text)
        except Exception as exc:
            raise UserError(_("Gemini returned non-JSON output. Response: %s") % text[:500]) from exc

    def _call_gemini_text_for_payload(self, prompt, image_b64, filename):
        """Call Gemini for a free-form text response from an image/PDF payload."""
        ir_config = self.env['ir.config_parameter'].sudo()
        api_key = (ir_config.get_param('jigsaw.gemini_api_key') or '').strip()
        requested_model = self._normalize_gemini_model_name(
            ir_config.get_param('jigsaw.gemini_model') or ''
        ) or 'gemini-2.0-flash'
        if not api_key:
            raise UserError(_('Please set Gemini API Key in PurpleMaps settings.'))

        supported_models = self._list_supported_gemini_models(api_key)
        model = requested_model
        if supported_models and requested_model not in supported_models:
            preferred = [
                'gemini-2.5-flash',
                'gemini-2.0-flash',
                'gemini-1.5-flash-latest',
                'gemini-1.5-flash',
            ]
            fallback = next((m for m in preferred if m in supported_models), supported_models[0])
            model = fallback

        mime_type = mimetypes.guess_type(filename or '')[0] or 'image/png'
        payload = {
            "contents": [{
                "parts": [
                    {"text": prompt},
                    {"inline_data": {"mime_type": mime_type, "data": image_b64}},
                ]
            }]
        }
        url = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s" % (model, api_key)
        req = request.Request(
            url=url,
            data=json.dumps(payload).encode('utf-8'),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with request.urlopen(req, timeout=90) as response:
                body = response.read().decode('utf-8')
        except error.HTTPError as exc:
            err_body = exc.read().decode('utf-8', errors='ignore')
            raise UserError(
                _("Gemini API request failed for model '%s': %s") % (model, err_body)
            ) from exc
        except Exception as exc:
            raise UserError(_("Could not connect to Gemini: %s") % str(exc)) from exc

        data = json.loads(body or '{}')
        candidates = data.get('candidates') or []
        if not candidates:
            raise UserError(_('Gemini did not return any candidates.'))
        parts = (candidates[0].get('content') or {}).get('parts') or []
        return ''.join(part.get('text', '') for part in parts if isinstance(part, dict))

    def action_run_ocr(self):
        self.ensure_one()
        if not self.ai_source_image:
            raise UserError(_('No source image/PDF to OCR.'))
        image_data = self.ai_source_image.decode('utf-8') if isinstance(self.ai_source_image, bytes) else self.ai_source_image
        prompt = (
            "Extract ALL readable text from this document/image, preserving line breaks "
            "and reading order. Return plain text only, no commentary, no markdown fences."
        )
        text = self._call_gemini_text_for_payload(prompt, image_data, self.ai_source_image_filename)
        self.ai_ocr_text = (text or '').strip()
        return {'ocr_text': self.ai_ocr_text}

    def _fund_structure_context_for_llm(self):
        """Compact text summary of entities and links for LLM context (size-capped)."""
        self.ensure_one()
        data = self.get_diagram_data(self.id)
        nodes = data.get('nodes') or []
        links = data.get('links') or []
        if not nodes:
            return "No entities in this fund map yet."
        id_to_name = {n['id']: (n.get('name') or str(n['id'])) for n in nodes}
        lines = [
            f"Diagram: {self.name or 'Untitled'}",
            f"Entities: {len(nodes)} | Relationships: {len(links)}",
            "",
            "Entities (id | name | type | jurisdiction):",
        ]
        for n in nodes:
            jur = n.get('jurisdiction') or n.get('country') or ''
            lines.append(
                "  %s | %s | %s | %s"
                % (n['id'], n.get('name') or '', n.get('type') or '', jur)
            )
        lines.append("")
        lines.append("Relationships (source → target | type | ownership %):")
        for rel in links:
            sn = id_to_name.get(rel.get('source'), rel.get('source'))
            tn = id_to_name.get(rel.get('target'), rel.get('target'))
            lines.append(
                "  %s → %s | %s | %s"
                % (sn, tn, rel.get('type') or '', rel.get('percent'))
            )
        text = "\n".join(lines)
        max_len = 14000
        if len(text) > max_len:
            text = text[:max_len] + _("\n…(structure truncated for size)")
        return text

    def _call_gemini_chat_text(self, system_instruction, contents_list):
        """Multi-turn text chat via Gemini generateContent."""
        ir_config = self.env['ir.config_parameter'].sudo()
        api_key = (ir_config.get_param('jigsaw.gemini_api_key') or '').strip()
        requested_model = self._normalize_gemini_model_name(
            ir_config.get_param('jigsaw.gemini_model') or ''
        ) or 'gemini-2.0-flash'
        if not api_key:
            raise UserError(_('Please set Gemini API Key in PurpleMaps settings.'))

        supported_models = self._list_supported_gemini_models(api_key)
        model = requested_model
        if supported_models and requested_model not in supported_models:
            preferred = [
                'gemini-2.5-flash',
                'gemini-2.0-flash',
                'gemini-1.5-flash-latest',
                'gemini-1.5-flash',
            ]
            fallback = next((m for m in preferred if m in supported_models), supported_models[0])
            model = fallback

        payload = {
            "systemInstruction": {"parts": [{"text": system_instruction}]},
            "contents": contents_list,
            "generationConfig": {
                "temperature": 0.4,
                "maxOutputTokens": 2048,
            },
        }
        url = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s" % (model, api_key)
        req = request.Request(
            url=url,
            data=json.dumps(payload).encode('utf-8'),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        try:
            with request.urlopen(req, timeout=120) as response:
                body = response.read().decode('utf-8')
        except error.HTTPError as exc:
            err_body = exc.read().decode('utf-8', errors='ignore')
            raise UserError(
                _("Gemini API request failed for model '%s': %s") % (model, err_body)
            ) from exc
        except Exception as exc:
            raise UserError(_("Could not connect to Gemini: %s") % str(exc)) from exc

        data = json.loads(body or '{}')
        candidates = data.get('candidates') or []
        if not candidates:
            raise UserError(_('Gemini did not return any candidates.'))
        parts = (candidates[0].get('content') or {}).get('parts') or []
        return ''.join(part.get('text', '') for part in parts if isinstance(part, dict))

    def action_gemini_fund_chat(self, message, history=None):
        """Answer a user question about this fund map using Gemini (server-side key)."""
        self.ensure_one()
        message = (message or '').strip()
        if not message:
            raise UserError(_('Please enter a message.'))
        history = history or []
        ctx = self._fund_structure_context_for_llm()
        system_text = (
            "You are an expert fund-structure analyst inside PurpleMaps (Odoo). "
            "The user sees an interactive ownership / entity map. "
            "Answer using ONLY the STRUCTURE block below for factual claims about entities, "
            "links, jurisdictions, and percentages. If something is not in the structure, say so. "
            "You may give general educational context if clearly labeled as general (not specific to this map). "
            "Be concise; use short paragraphs or bullet lists. Do not invent entity names or ownership.\n\n"
            "--- STRUCTURE ---\n"
            f"{ctx}"
        )
        contents = []
        for item in history:
            if not isinstance(item, dict):
                continue
            role = (item.get('role') or '').lower()
            text = (item.get('text') or item.get('content') or '').strip()
            if not text:
                continue
            if role == 'user':
                contents.append({"role": "user", "parts": [{"text": text}]})
            elif role in ('assistant', 'model', 'bot'):
                contents.append({"role": "model", "parts": [{"text": text}]})
        contents.append({"role": "user", "parts": [{"text": message}]})
        reply = self._call_gemini_chat_text(system_text, contents)
        return {'reply': (reply or '').strip()}

    def _build_import_diagram_name(self):
        now_local = fields.Datetime.context_timestamp(self, fields.Datetime.now())
        return _("Capital Import %s") % now_local.strftime('%Y-%m-%d %H:%M')

    def action_generate_entities_from_image(self):
        self.ensure_one()
        if not self.ai_source_image:
            raise UserError(_('Upload an image first in the AI Import section.'))

        image_data = self.ai_source_image.decode('utf-8') if isinstance(self.ai_source_image, bytes) else self.ai_source_image
        parsed = self._call_gemini_entity_extraction(image_data, self.ai_source_image_filename)
        entities = parsed.get('entities') or []
        relations = parsed.get('relations') or []
        if not entities:
            raise UserError(_('No entities detected in the uploaded image.'))

        # Always create a new import diagram so the source and imported graph stay separate.
        imported_diagram = self.create({
            'name': self._build_import_diagram_name(),
            'description': _('Auto-created from AI image import.'),
            'company_id': self.company_id.id or self.env.company.id,
            'ai_source_image': self.ai_source_image,
            'ai_source_image_filename': self.ai_source_image_filename,
        })

        entity_model = self.env['jigsaw.entity']
        relation_model = self.env['jigsaw.relation']
        created_by_name = {}
        layout = {}
        for index, item in enumerate(entities):
            name = (item.get('name') or '').strip()
            if not name:
                continue
            key = name.lower()
            if key in created_by_name:
                continue

            try:
                pos_x = float(item.get('x'))
                pos_y = float(item.get('y'))
            except (TypeError, ValueError):
                # Deterministic fallback layout if model omits coordinates.
                col = index % 6
                row = index // 6
                pos_x = 180 + (col * 280)
                pos_y = 120 + (row * 180)

            created = entity_model.create({
                'name': name,
                'type': self._map_entity_type(item.get('type')),
                'diagram_id': imported_diagram.id,
                'company_id': imported_diagram.company_id.id or self.env.company.id,
            })
            created_by_name[key] = created
            imported_diagram.entity_ids = [(4, created.id)]
            layout[str(created.id)] = {'x': pos_x, 'y': pos_y}

        for item in relations:
            source_name = (item.get('source') or '').strip().lower()
            target_name = (item.get('target') or '').strip().lower()
            if not source_name or not target_name:
                continue
            source = created_by_name.get(source_name)
            target = created_by_name.get(target_name)
            if not source or not target:
                continue
            duplicate = relation_model.search_count([
                ('source_entity_id', '=', source.id),
                ('target_entity_id', '=', target.id),
                ('relationship_type', '=', self._map_relation_type(item.get('relationship_type'))),
            ])
            if duplicate:
                continue
            relation_model.create({
                'source_entity_id': source.id,
                'target_entity_id': target.id,
                'relationship_type': self._map_relation_type(item.get('relationship_type')),
                'ownership_pct': self._parse_ownership_pct(item.get('ownership_pct')),
                'company_id': imported_diagram.company_id.id or self.env.company.id,
            })

        imported_diagram.layout_data = json.dumps(layout)
        return imported_diagram.action_open_workshop()

    @api.model
    def create_from_image_payload(self, image_b64, filename, name=None):
        """Create a brand new diagram from an uploaded image/PDF and populate
        it with AI-extracted entities and relations in a single call.

        Used by the visualizer's "Import Fund Map" button so users can import
        without first navigating to the diagram form.

        Returns:
            dict: { 'diagram_id': <int>, 'name': <str> }
        """
        if not image_b64:
            raise UserError(_('No image data provided.'))

        diagram = self.create({
            'name': name or self._build_import_diagram_name(),
            'description': _('Auto-created from AI image import.'),
            'company_id': self.env.company.id,
            'ai_source_image': image_b64,
            'ai_source_image_filename': filename or 'import.png',
        })

        parsed = self._call_gemini_entity_extraction(image_b64, filename or 'import.png')
        entities = parsed.get('entities') or []
        relations = parsed.get('relations') or []

        if not entities:
            raise UserError(_('No entities detected in the uploaded image.'))

        entity_model = self.env['jigsaw.entity']
        relation_model = self.env['jigsaw.relation']
        created_by_name = {}
        layout = {}

        for index, item in enumerate(entities):
            ent_name = (item.get('name') or '').strip()
            if not ent_name:
                continue
            key = ent_name.lower()
            if key in created_by_name:
                continue

            try:
                pos_x = float(item.get('x'))
                pos_y = float(item.get('y'))
            except (TypeError, ValueError):
                col = index % 6
                row = index // 6
                pos_x = 180 + (col * 280)
                pos_y = 120 + (row * 180)

            created = entity_model.create({
                'name': ent_name,
                'type': self._map_entity_type(item.get('type')),
                'diagram_id': diagram.id,
                'company_id': diagram.company_id.id or self.env.company.id,
            })
            created_by_name[key] = created
            diagram.entity_ids = [(4, created.id)]
            layout[str(created.id)] = {'x': pos_x, 'y': pos_y}

        for item in relations:
            source_name = (item.get('source') or '').strip().lower()
            target_name = (item.get('target') or '').strip().lower()
            if not source_name or not target_name:
                continue
            source = created_by_name.get(source_name)
            target = created_by_name.get(target_name)
            if not source or not target:
                continue
            mapped_rel = self._map_relation_type(item.get('relationship_type'))
            duplicate = relation_model.search_count([
                ('source_entity_id', '=', source.id),
                ('target_entity_id', '=', target.id),
                ('relationship_type', '=', mapped_rel),
            ])
            if duplicate:
                continue
            relation_model.create({
                'source_entity_id': source.id,
                'target_entity_id': target.id,
                'relationship_type': mapped_rel,
                'ownership_pct': self._parse_ownership_pct(item.get('ownership_pct')),
                'company_id': diagram.company_id.id or self.env.company.id,
            })

        diagram.layout_data = json.dumps(layout)
        return {'diagram_id': diagram.id, 'name': diagram.name}

    @api.model
    def get_dashboard_data(self):
        """Aggregated stats for the PurpleMaps dashboard."""
        entity_model = self.env['jigsaw.entity']
        relation_model = self.env['jigsaw.relation']
        diagram_model = self.env['jigsaw.diagram']

        total_entities = entity_model.search_count([])
        total_relations = relation_model.search_count([])
        total_diagrams = diagram_model.search_count([])

        # Group counts via read_group for performance
        def _group(model_name, field):
            rows = self.env[model_name].read_group(
                domain=[], fields=[field], groupby=[field],
            )
            out = []
            for row in rows:
                value = row.get(field)
                if isinstance(value, tuple):
                    value = value[1]
                if value in (False, None, ''):
                    label = 'Unspecified'
                else:
                    label = value
                out.append({'label': label, 'count': row.get(f'{field}_count', 0)})
            out.sort(key=lambda r: r['count'], reverse=True)
            return out

        by_type = _group('jigsaw.entity', 'type')
        by_pe_type = _group('jigsaw.entity', 'pe_entity_type')
        by_stage = _group('jigsaw.entity', 'pe_stage')
        by_status = _group('jigsaw.entity', 'pe_status')
        by_industry = _group('jigsaw.entity', 'pe_industry')
        by_compliance = _group('jigsaw.entity', 'compliance_status')

        # Sum total valuation & invested
        agg = entity_model.read_group(
            domain=[],
            fields=['valuation_current:sum', 'amount_invested:sum', 'burn_rate:sum'],
            groupby=[],
        )
        sums = agg[0] if agg else {}
        total_valuation = sums.get('valuation_current') or 0.0
        total_invested = sums.get('amount_invested') or 0.0
        total_burn = sums.get('burn_rate') or 0.0

        # Top 10 by current valuation
        top_entities = entity_model.search_read(
            [('valuation_current', '>', 0)],
            fields=['name', 'valuation_current', 'pe_stage', 'pe_status', 'performance_irr'],
            limit=10,
            order='valuation_current desc',
        )

        # Recent diagrams
        recent_diagrams = diagram_model.search_read(
            [], fields=['name', 'create_date', 'description'],
            limit=8, order='create_date desc',
        )
        for d in recent_diagrams:
            cd = d.get('create_date')
            d['create_date'] = cd.strftime('%Y-%m-%d %H:%M') if cd else ''

        # Risk flag counts
        risk_flags = {}
        for flag in ['risk_high_burn', 'risk_down_round', 'risk_founder_dispute',
                     'risk_compliance_breach', 'risk_regulatory_exposure']:
            risk_flags[flag] = entity_model.search_count([(flag, '=', True)])

        # Tag counts
        tag_counts = {}
        for tag in ['tag_top_10', 'tag_followon_priority', 'tag_under_watch',
                    'tag_exit_ready', 'tag_strategic_focus']:
            tag_counts[tag] = entity_model.search_count([(tag, '=', True)])

        return {
            'totals': {
                'entities': total_entities,
                'relations': total_relations,
                'diagrams': total_diagrams,
                'valuation_current_sum': total_valuation,
                'amount_invested_sum': total_invested,
                'burn_rate_sum': total_burn,
                'currency_symbol': self.env.company.currency_id.symbol or '$',
            },
            'by_type': by_type,
            'by_pe_type': by_pe_type,
            'by_stage': by_stage,
            'by_status': by_status,
            'by_industry': by_industry,
            'by_compliance': by_compliance,
            'top_entities': top_entities,
            'recent_diagrams': recent_diagrams,
            'risk_flags': risk_flags,
            'tag_counts': tag_counts,
        }

    @api.model
    def get_diagram_data(self, diagram_id):
        diagram = self.browse(diagram_id)

        image_info = {
            'has_image': bool(diagram.ai_source_image),
            'filename': diagram.ai_source_image_filename or '',
            'ocr_text': diagram.ai_ocr_text or '',
        }

        diagram_title = diagram.name or ''

        seed_entity_ids = diagram.entity_ids.ids
        if not seed_entity_ids:
            return {
                'nodes': [], 'links': [], 'layout': {},
                'image': image_info,
                'diagram_name': diagram_title,
            }

        # Recursively find all connected entities
        all_entity_ids = set(seed_entity_ids)
        to_process = set(seed_entity_ids)
        processed = set()
        
        all_relations = self.env['jigsaw.relation']
        
        while to_process:
            current_id = to_process.pop()
            processed.add(current_id)
            
            # Find relations connected to this entity
            rels = self.env['jigsaw.relation'].search([
                '|', ('source_entity_id', '=', current_id), ('target_entity_id', '=', current_id)
            ])
            all_relations |= rels
            
            for rel in rels:
                pid, cid = rel.source_entity_id.id, rel.target_entity_id.id
                if pid not in processed:
                    all_entity_ids.add(pid)
                    to_process.add(pid)
                if cid not in processed:
                    all_entity_ids.add(cid)
                    to_process.add(cid)

        entities = self.env['jigsaw.entity'].browse(list(all_entity_ids))
        
        nodes = []
        for entity in entities:
            nodes.append({
                'id': entity.id,
                'name': entity.name,
                'type': entity.type,
                'country': entity.country_id.code if entity.country_id else False,
                'jurisdiction': entity.jurisdiction or (entity.country_id.name if entity.country_id else False),
                'subtype': entity.subtype or '',
                'registration_no': entity.registration_no or '',
                'entity_id_external': entity.entity_id_external or '',
                'commitment_amount': entity.commitment_amount or 0.0,
                'capital_contributed': entity.capital_contributed or 0.0,
                'tax_id_number': entity.tax_id_number or '',
                'registered_office': entity.registered_office or '',
                'formation_date': entity.formation_date.strftime('%Y-%m-%d') if entity.formation_date else '',
                'fund_family_name': entity.fund_family_name or '',
                'directors': entity.directors or '',
                'officers': entity.officers or '',
                'authorised_signatory': entity.authorised_signatory or '',
                'region': entity.region or '',
                'tax_filing_deadline': entity.tax_filing_deadline.strftime('%Y-%m-%d') if entity.tax_filing_deadline else '',
                # ── Entity Basics ──
                'pe_entity_type': entity.pe_entity_type or '',
                'pe_jurisdiction': entity.pe_jurisdiction or '',
                'pe_industry': entity.pe_industry or '',
                'pe_stage': entity.pe_stage or '',
                'pe_status': entity.pe_status or '',
                # ── Investment & Ownership ──
                'investment_date': entity.investment_date.strftime('%Y-%m-%d') if entity.investment_date else '',
                'investment_round': entity.investment_round or '',
                'ownership_pct_overall': entity.ownership_pct_overall or 0.0,
                'amount_invested': entity.amount_invested or 0.0,
                'valuation_current': entity.valuation_current or 0.0,
                'valuation_last': entity.valuation_last or 0.0,
                'performance_irr': entity.performance_irr or 0.0,
                'performance_moic': entity.performance_moic or 0.0,
                'investor_type': entity.investor_type or '',
                'spv_linked': entity.spv_linked,
                # ── Portfolio Performance ──
                'revenue_band': entity.revenue_band or '',
                'burn_rate': entity.burn_rate or 0.0,
                'runway_months': entity.runway_months or 0,
                'profitability': entity.profitability or '',
                'high_growth_flag': entity.high_growth_flag,
                'exit_pipeline': entity.exit_pipeline or '',
                # ── Compliance & Governance ──
                'compliance_status': entity.compliance_status or '',
                'board_meetings': entity.board_meetings,
                'board_meeting_frequency': entity.board_meeting_frequency or '',
                'financial_filings': entity.financial_filings,
                'roc_sec_status': entity.roc_sec_status or '',
                'kyc_aml': entity.kyc_aml or '',
                'document_completeness': entity.document_completeness or '',
                'regulatory_flag_fema': entity.regulatory_flag_fema,
                'regulatory_flag_odi': entity.regulatory_flag_odi,
                'regulatory_flag_fdi': entity.regulatory_flag_fdi,
                # ── Cap Table & Securities ──
                'share_class': entity.share_class or '',
                'esop_pct': entity.esop_pct or 0.0,
                'last_round_dilution': entity.last_round_dilution or 0.0,
                'liquidation_preference': entity.liquidation_preference or '',
                'anti_dilution': entity.anti_dilution,
                # ── Stakeholders ──
                'board_seat': entity.board_seat,
                'observer_rights': entity.observer_rights,
                'founder_status': entity.founder_status or '',
                'management_changes': entity.management_changes,
                'co_investors': entity.co_investors,
                # ── Timeline ──
                'next_board_meeting': entity.next_board_meeting.strftime('%Y-%m-%d') if entity.next_board_meeting else '',
                'last_valuation_date': entity.last_valuation_date.strftime('%Y-%m-%d') if entity.last_valuation_date else '',
                'exit_timeline_estimate': entity.exit_timeline_estimate or '',
                # ── Documents ──
                'documents_uploaded': entity.documents_uploaded or '',
                'latest_financials': entity.latest_financials,
                'sha_ssa': entity.sha_ssa or '',
                'due_diligence': entity.due_diligence or '',
                # ── File attachments (metadata only; binary loaded on download) ──
                'entity_documents': [
                    {'id': d.id, 'name': d.name, 'filename': d.file_name or ''}
                    for d in entity.document_ids
                ],
                # ── Fund Structuring ──
                'fund_name': entity.fund_name or '',
                'gp_lp_mapping': entity.gp_lp_mapping,
                'co_investment': entity.co_investment,
                'spv_vs_direct': entity.spv_vs_direct or '',
                'cross_holdings': entity.cross_holdings,
                # ── Risk & Alerts ──
                'risk_high_burn': entity.risk_high_burn,
                'risk_down_round': entity.risk_down_round,
                'risk_founder_dispute': entity.risk_founder_dispute,
                'risk_compliance_breach': entity.risk_compliance_breach,
                'risk_regulatory_exposure': entity.risk_regulatory_exposure,
                # ── Tags ──
                'tag_top_10': entity.tag_top_10,
                'tag_followon_priority': entity.tag_followon_priority,
                'tag_under_watch': entity.tag_under_watch,
                'tag_exit_ready': entity.tag_exit_ready,
                'tag_strategic_focus': entity.tag_strategic_focus,
            })
            
        links = []
        for rel in all_relations:
            links.append({
                'source': rel.source_entity_id.id,
                'target': rel.target_entity_id.id,
                'percent': rel.ownership_pct,
                'type': rel.relationship_type,
            })
            
        return {
            'nodes': nodes,
            'links': links,
            'layout': json.loads(diagram.layout_data or '{}'),
            'image': image_info,
            'diagram_name': diagram_title,
        }



