from odoo import models, fields


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    jigsaw_gemini_api_key = fields.Char(
        string='Gemini API Key',
        config_parameter='jigsaw.gemini_api_key',
    )
    jigsaw_gemini_model = fields.Char(
        string='Gemini Model',
        config_parameter='jigsaw.gemini_model',
        default='gemini-2.0-flash',
    )
