/** @odoo-module **/

import { Component } from "@odoo/owl";
import { FilterSchema } from "../utils/FilterSchema";

/**
 * WorkshopFilterModal — full-fledged "Advanced Filter" popup.
 *
 * Renders only when `state.showFilterModal` is true. Each rule is laid out
 * horizontally across one row so dropdowns get the room they need.
 */
export class WorkshopFilterModal extends Component {
    static template = "jigsaw.WorkshopFilterModal";
    static props = {
        state: Object,
        close: Function,
        addFilterRule: Function,
        removeFilterRule: Function,
        clearFilterRules: Function,
        toggleFilterRule: Function,
        setFilterRuleCategory: Function,
        setFilterRuleField: Function,
        setFilterRuleOperator: Function,
        setFilterRuleValue: Function,
        setFilterRulesMode: Function,
    };

    setup() {
        this.schema = FilterSchema;
    }

    fieldsFor(categoryKey) {
        const cat = FilterSchema.findCategory(categoryKey);
        return cat ? cat.fields : [];
    }

    operatorsFor(type) {
        return FilterSchema.operatorsFor(type);
    }

    selectionOptionsFor(rule) {
        const f = FilterSchema.findField(rule.category, rule.field);
        return f && f.options ? f.options : [];
    }

    operatorNeedsValue(rule) {
        if (!rule || !rule.operator) return false;
        if (rule.operator === "set" || rule.operator === "notset") return false;
        if (rule.type === "boolean") return false;
        return true;
    }

    get visibleNodeCount() {
        const nodes = this.props.state.nodes || [];
        return nodes.filter((n) => !this._isNodeFilteredOut(n)).length;
    }

    _isNodeFilteredOut(node) {
        const state = this.props.state;
        const rules = (state.filterRules || []).filter((r) => r && r.enabled !== false && r.field);
        if (rules.length === 0) return false;
        const mode = state.filterRulesMode || "all";
        const passes = (r) => {
            const v = node[r.field];
            if (r.operator === "set") return v !== undefined && v !== null && v !== "" && v !== false;
            if (r.operator === "notset") return v === undefined || v === null || v === "" || v === false;
            if (r.type === "boolean") return r.operator === "true" ? !!v : !v;
            if (r.type === "number") {
                const a = parseFloat(v), b = parseFloat(r.value);
                if (Number.isNaN(a) || Number.isNaN(b)) return false;
                return ({ eq: a===b, ne: a!==b, gt: a>b, gte: a>=b, lt: a<b, lte: a<=b })[r.operator] || false;
            }
            if (r.type === "selection") {
                if (r.operator === "is") return v === r.value;
                if (r.operator === "isnot") return v !== r.value;
                return false;
            }
            if (r.type === "date") {
                const a = v ? new Date(v).getTime() : NaN;
                const b = r.value ? new Date(r.value).getTime() : NaN;
                if (Number.isNaN(a) || Number.isNaN(b)) return false;
                if (r.operator === "is") return Math.floor(a/86400000)===Math.floor(b/86400000);
                if (r.operator === "before") return a < b;
                if (r.operator === "after") return a > b;
                return false;
            }
            const a = (v||"").toString().toLowerCase();
            const b = (r.value||"").toString().toLowerCase();
            if (r.operator === "contains") return b && a.includes(b);
            if (r.operator === "ncontains") return b && !a.includes(b);
            if (r.operator === "is") return a === b;
            if (r.operator === "isnot") return a !== b;
            return false;
        };
        const ok = mode === "any" ? rules.some(passes) : rules.every(passes);
        return !ok;
    }

    onBackdropClick(ev) {
        if (ev.target === ev.currentTarget) {
            this.props.close();
        }
    }
}
