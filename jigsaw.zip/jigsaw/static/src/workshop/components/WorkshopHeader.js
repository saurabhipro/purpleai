/** @odoo-module **/

import { Component } from "@odoo/owl";

export class WorkshopHeader extends Component {
    static template = "jigsaw.WorkshopHeader";
    static props = {
        state: Object,
        onClose: Function,
        onExport: Function,
        onOrganize: Function,
        onFit: Function,
        onAddEntity: Function,
        toggleSidebar: Function,
        togglePdfViewer: Function,
        toggleAiChat: Function,
        toggleFilterModal: Function,
        triggerImportPicker: { type: Function, optional: true },
        toggleOwnershipMenu: Function,
        setOwnershipDirection: Function,
        clearOwnershipFilter: Function,
        updateOwnershipFilter: Function,
        onZoomIn: Function,
        onZoomOut: Function,
        toggleLayoutMenu: Function,
        /** Pre-bound from parent — same pattern as onClose (QWeb + child templates). */
        layoutPickBalanced: Function,
        layoutPickHierarchical: Function,
        layoutPickCircular: Function,
        layoutPickOrthogonal: Function,
        layoutPickSales: Function,
        openFundsPicker: Function,
    };
}
