/** @odoo-module **/

import { Component, useState, useRef, onPatched } from "@odoo/owl";

export class WorkshopAiChatPanel extends Component {
    static template = "jigsaw.WorkshopAiChatPanel";
    static props = {
        state: Object,
        sendMessage: Function,
        clearThread: Function,
        close: Function,
    };

    setup() {
        this.inputState = useState({ value: "" });
        this.threadRef = useRef("thread");
        onPatched(() => this._scrollBottom());
    }

    _scrollBottom() {
        const el = this.threadRef.el;
        if (el) {
            el.scrollTop = el.scrollHeight;
        }
    }

    onKeydown(ev) {
        if (ev.key === "Enter" && !ev.shiftKey) {
            ev.preventDefault();
            this.submit();
        }
    }

    submit() {
        const text = (this.inputState.value || "").trim();
        if (!text || this.props.state.aiChatSending) {
            return;
        }
        this.inputState.value = "";
        this.props.sendMessage(text);
    }
}
