/** @odoo-module **/

import { Component, useState } from "@odoo/owl";
import { FilterSchema } from "../utils/FilterSchema";

const SIDEBAR_MIN = 320;
const SIDEBAR_MAX = 900;

export class WorkshopSidebar extends Component {
    static template = "jigsaw.WorkshopSidebar";
    static props = {
        state: Object,
        toggleSidebar: Function,
        toggleDataTab: Function,
        onUpdateProperty: Function,
        onDeleteEntity: Function,
        onAddChild: Function,
        onAddParent: Function,
        onSelectNode: Function,
        onOpenFullForm: { type: Function, optional: true },
    };

    setup() {
        this.schema = FilterSchema;
        this.SIDEBAR_MIN = SIDEBAR_MIN;
        this.SIDEBAR_MAX = SIDEBAR_MAX;
        this._dragState = null;
        // Bind once so add/removeEventListener target the same fns
        this._onResizeMove = this._onResizeMove.bind(this);
        this._onResizeEnd = this._onResizeEnd.bind(this);
        // Track which property panel sections are expanded.
        // "_identity" is always open by default; one PE category opens by default.
        this.ui = useState({
            openSections: {
                _identity: true,
                entity_basics: true,
                investment: false,
                performance: false,
                compliance: false,
                captable: false,
                stakeholders: false,
                timeline: false,
                documents: false,
                fund: false,
                risk: false,
                tags: false,
            },
        });
    }

    toggleSection(key) {
        this.ui.openSections[key] = !this.ui.openSections[key];
    }

    isOpen(key) {
        return !!this.ui.openSections[key];
    }

    // ── Selection helpers ───────────────────────────────────────────
    optionLabel(field, value) {
        if (!field || !field.options) return value || "";
        const hit = field.options.find((o) => o.value === value);
        return hit ? hit.label : (value || "");
    }

    // Categories used in the properties panel — comes straight from FilterSchema.
    get propertyCategories() {
        return this.schema.categories;
    }

    // Quick summary for collapsed section header ("3 set")
    sectionSummary(node, cat) {
        if (!node) return "";
        let setCount = 0;
        for (const f of cat.fields) {
            const v = node[f.key];
            if (f.type === "boolean") {
                if (v) setCount++;
            } else if (v !== undefined && v !== null && v !== "" && v !== 0) {
                setCount++;
            }
        }
        return setCount ? `${setCount} set` : "—";
    }

    // Friendly handlers
    onChangeField(node, field, ev) {
        let value = ev.target.value;
        if (field.type === "number") {
            value = value === "" ? 0 : parseFloat(value);
            if (Number.isNaN(value)) value = 0;
        }
        this.props.onUpdateProperty(node.id, field.key, value);
    }

    onToggleBoolField(node, field, ev) {
        this.props.onUpdateProperty(node.id, field.key, !!ev.target.checked);
    }

    // ── Resize handle (drag on the left edge of the sidebar) ─────────
    onResizeStart(ev) {
        ev.preventDefault();
        const startX = ev.clientX;
        const startWidth = this.props.state.sidebarWidth || 460;
        this._dragState = { startX, startWidth };
        document.body.style.cursor = "col-resize";
        document.body.style.userSelect = "none";
        window.addEventListener("mousemove", this._onResizeMove);
        window.addEventListener("mouseup", this._onResizeEnd);
    }

    _onResizeMove(ev) {
        if (!this._dragState) return;
        const dx = this._dragState.startX - ev.clientX; // drag-left → wider
        let next = this._dragState.startWidth + dx;
        if (next < SIDEBAR_MIN) next = SIDEBAR_MIN;
        if (next > SIDEBAR_MAX) next = SIDEBAR_MAX;
        this.props.state.sidebarWidth = next;
    }

    _onResizeEnd() {
        if (!this._dragState) return;
        try {
            localStorage.setItem("jigsaw.sidebarWidth", String(this.props.state.sidebarWidth));
        } catch (_e) {
            /* localStorage unavailable — silently ignore */
        }
        this._dragState = null;
        document.body.style.cursor = "";
        document.body.style.userSelect = "";
        window.removeEventListener("mousemove", this._onResizeMove);
        window.removeEventListener("mouseup", this._onResizeEnd);
    }

    onResizeDoubleClick() {
        // Snap back to default width
        this.props.state.sidebarWidth = 460;
        try {
            localStorage.setItem("jigsaw.sidebarWidth", "460");
        } catch (_e) { /* ignore */ }
    }
}
