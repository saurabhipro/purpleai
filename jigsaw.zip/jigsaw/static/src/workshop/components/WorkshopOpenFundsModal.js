/** @odoo-module **/

import { Component } from "@odoo/owl";

/**
 * Modal to pick one or more jigsaw.diagram (funds) and open them in PurpleMaps.
 */
export class WorkshopOpenFundsModal extends Component {
    static template = "jigsaw.WorkshopOpenFundsModal";
    static props = {
        state: Object,
        currentDiagramId: { optional: true },
        close: Function,
        toggleSelect: Function,
        selectAllVisible: Function,
        clearSelection: Function,
        openSelected: Function,
    };

    get filteredFunds() {
        const q = (this.props.state.openFundsQuery || "").trim().toLowerCase();
        const list = this.props.state.openFundsList || [];
        if (!q) return list;
        return list.filter((f) => (f.name || "").toLowerCase().includes(q));
    }

    get selectedCount() {
        const sel = this.props.state.openFundsSelected || {};
        return Object.keys(sel).filter((k) => sel[k]).length;
    }

    allVisibleSelected() {
        const vis = this.filteredFunds;
        if (!vis.length) return false;
        const sel = this.props.state.openFundsSelected || {};
        return vis.every((f) => sel[String(f.id)]);
    }

    onBackdropClick(ev) {
        if (ev.target === ev.currentTarget) {
            this.props.close();
        }
    }

    onSearchInput(ev) {
        this.props.state.openFundsQuery = ev.target.value;
    }
}
