/** @odoo-module **/

import { Component } from "@odoo/owl";

export class WorkshopExportModal extends Component {
    static template = "jigsaw.WorkshopExportModal";
    static props = {
        state: Object,
        diagramId: { optional: true },
        close: Function,
        exportExcel: Function,
        exportPdf: Function,
    };

    onBackdropClick(ev) {
        if (ev.target === ev.currentTarget) {
            this.props.close();
        }
    }
}
