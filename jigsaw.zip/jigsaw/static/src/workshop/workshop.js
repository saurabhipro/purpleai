/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component, onWillStart, onWillUnmount, useState, useRef, onMounted } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";

// Sub-components
import { WorkshopHeader } from "./components/WorkshopHeader";
import { WorkshopSidebar } from "./components/WorkshopSidebar";
import { WorkshopCanvas } from "./components/WorkshopCanvas";
import { WorkshopModals } from "./components/WorkshopModals";
import { WorkshopFilterModal } from "./components/WorkshopFilterModal";

// Utilities
import { Geometry } from "./utils/Geometry";
import { Constants } from "./utils/Constants";

// Hooks
import { useWorkshopInteractions } from "./utils/Interactions";
import { useEntityActions } from "./utils/useEntityActions";
import { useLayoutActions } from "./utils/useLayoutActions";
import { useCommentActions } from "./utils/useCommentActions";
import { useUIActions } from "./utils/useUIActions";

export class JigsawWorkshop extends Component {
    static template = "jigsaw.Workshop";
    static components = { WorkshopHeader, WorkshopSidebar, WorkshopCanvas, WorkshopModals, WorkshopFilterModal };

    setup() {
        // ── Services ──────────────────────────────────────────────────────────
        this.action = useService("action");
        this.orm = useService("orm");
        this.notification = useService("notification");

        // ── Shared Reactive State ─────────────────────────────────────────────
        this.state = useState({
            nodes: [],
            links: [],
            layout: {},
            loading: true,
            zoom: Constants.DEFAULT_ZOOM,
            offsetX: Constants.DEFAULT_OFFSET_X,
            offsetY: Constants.DEFAULT_OFFSET_Y,
            selectedNodeIds: [],
            activeSidebar: "data",       // 'data' | 'comments' | null
            isSaving: false,
            showFilterMenu: false,
            showOwnershipMenu: false,
            ownershipDirection: "down",
            ownershipPctThreshold: 10,
            ownershipPctType: "more",
            ownershipFilterEnabled: false,
            ownershipVisibleNodeIds: [],
            filterText: "",
            filterType: "",
            activeFilters: [],
            comments: [],
            activeDataTab: "properties", // 'properties' | 'relationships' | 'files'
            showCommentInputForNode: null,
            newCommentText: "",
            showResolvedComments: false,
            showAllComments: true,
            contextMenu: { visible: false, x: 0, y: 0, nodeId: null, activeMenu: null },
            linkingNodeId: null,
            linkingMode: null,           // 'parent' | 'child'
            editingNode: null,
            editingLink: null,
            showPdfViewer: false,
            hasAiImage: false,
            aiImageFilename: "",
            ocrText: "",
            ocrRunning: false,
            ocrSearch: "",
            filterRules: [],
            filterRulesMode: "all", // 'all' (AND) | 'any' (OR)
            showFilterModal: false,
            // ── Right sidebar resizing ────────────────────────────────────
            sidebarWidth: parseInt(localStorage.getItem("jigsaw.sidebarWidth") || "460", 10),
        });

        // ── Refs & Diagram ID ─────────────────────────────────────────────────
        this.canvasRef = useRef("canvas");
        const rawId =
            this.props.action.params?.diagram_id ||
            this.props.action.context?.active_id ||
            this.props.action.context?.default_diagram_id ||
            this.props.action.res_id;
        this.diagramId = rawId ? parseInt(rawId) : null;

        // ── Hook: UI Actions ──────────────────────────────────────────────────
        // Initialised first because entity/layout hooks depend on isNodeFilteredOut
        const ui = useUIActions(this.state, {
            action: this.action,
            notification: this.notification,
        });
        Object.assign(this, ui);

        // ── Hook: Layout Actions ──────────────────────────────────────────────
        // Depends on isNodeFilteredOut from ui and saveLayout from entity (deferred via lambda)
        const layout = useLayoutActions(
            this.state,
            this.canvasRef,
            () => this.saveLayout(),          // deferred: saveLayout defined after entity hook
            (node) => this.isNodeFilteredOut(node)
        );
        Object.assign(this, layout);

        // ── Hook: Entity & Link Actions ───────────────────────────────────────
        const entity = useEntityActions(
            this.state,
            { orm: this.orm, action: this.action, notification: this.notification },
            this.diagramId,
            () => this.treeLayout()           // callback provided to ensureDefaultLayout
        );
        Object.assign(this, entity);

        // ── Hook: Comment Actions ─────────────────────────────────────────────
        const comments = useCommentActions(this.state);
        Object.assign(this, comments);

        // ── Lifecycle ─────────────────────────────────────────────────────────
        onWillStart(async () => {
            await this.ensureDiagramId();
            await this.loadData();
        });

        onMounted(() => {
            this.cleanupInteractions = useWorkshopInteractions(this.canvasRef, this.state, {
                onCreateLink: (id) => this.onCreateLink(id),
                updateOwnershipFilter: () => this.updateOwnershipFilter(),
                saveLayout: () => this.saveLayout(),
                onEditEntity: (id) => this.onEditEntity(id),
                onEditLink: (id) => this.onEditLink(id),
                notify: (msg, type) => this.notification.add(msg, { type }),
            });
        });

        onWillUnmount(() => {
            if (this.cleanupInteractions) this.cleanupInteractions();
        });
    }

    // ── Geometry (pass-through) ───────────────────────────────────────────────

    getLinkPath(link) {
        const info = this.getLinkInfo(link);
        return info ? info.d : "";
    }

    getLinkInfo(link) {
        return Geometry.getLinkInfo(link, this.state);
    }

    get aiImageUrl() {
        if (!this.diagramId || !this.state.hasAiImage) return "";
        return `/web/image/jigsaw.diagram/${this.diagramId}/ai_source_image?unique=${this.diagramId}`;
    }

    get aiSourceContentUrl() {
        if (!this.diagramId || !this.state.hasAiImage) return "";
        const fname = encodeURIComponent(this.state.aiImageFilename || "source");
        // Use Odoo's standard /web/content pattern with `?filename=` (matches
        // the way the built-in FileViewer constructs URLs for ir.binary fields).
        return `/web/content/jigsaw.diagram/${this.diagramId}/ai_source_image?filename=${fname}&unique=${this.diagramId}`;
    }

    get aiImageDownloadUrl() {
        if (!this.aiSourceContentUrl) return "";
        return `${this.aiSourceContentUrl}&download=true`;
    }

    get aiImageIsPdf() {
        return (this.state.aiImageFilename || "").toLowerCase().endsWith(".pdf");
    }

    get pdfViewerUrl() {
        if (!this.aiImageIsPdf || !this.aiSourceContentUrl) return "";
        // Match Odoo's built-in FileViewer URL format exactly:
        //   viewer.html?file=<encoded_route>#pagemode=none
        // `pagemode=none` hides the sidebar so the document fills the panel,
        // mirroring how the chatter PDF viewer renders.
        const file = encodeURIComponent(this.aiSourceContentUrl);
        return `/web/static/lib/pdfjs/web/viewer.html?file=${file}#pagemode=none`;
    }

    get ocrLines() {
        const text = this.state.ocrText || "";
        if (!text) return [];
        const q = (this.state.ocrSearch || "").trim().toLowerCase();
        const lines = text.split(/\r?\n/);
        if (!q) return lines.map((line, i) => ({ i, line, match: false }));
        return lines
            .map((line, i) => ({ i, line, match: line.toLowerCase().includes(q) }))
            .filter((x) => x.match);
    }

    async ensureDiagramId() {
        if (this.diagramId) return;
        try {
            const rows = await this.orm.searchRead(
                "jigsaw.diagram",
                [],
                ["id"],
                { limit: 1, order: "id desc" }
            );
            if (rows && rows.length) {
                this.diagramId = rows[0].id;
            }
        } catch (e) {
            console.error("Failed to resolve default diagram:", e);
        }
    }

    openEntityForm(entityId) {
        if (!entityId) return;
        this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "jigsaw.entity",
            res_id: entityId,
            views: [[false, "form"]],
            target: "new",
        });
    }

    async runOcr() {
        if (!this.diagramId || this.state.ocrRunning) return;
        this.state.ocrRunning = true;
        try {
            const result = await this.orm.call(
                "jigsaw.diagram",
                "action_run_ocr",
                [this.diagramId],
            );
            this.state.ocrText = (result && result.ocr_text) || "";
            this.notification.add("Text extracted from document.", { type: "success" });
        } catch (e) {
            console.error(e);
            this.notification.add("OCR failed. Check Gemini API key.", { type: "danger" });
        } finally {
            this.state.ocrRunning = false;
        }
    }
}

registry.category("actions").add("jigsaw.workshop", JigsawWorkshop);
