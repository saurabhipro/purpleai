/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component, onWillStart, onWillUnmount, useState, useRef, onMounted } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";

// Sub-components
import { WorkshopHeader } from "./components/WorkshopHeader";
import { WorkshopSidebar } from "./components/WorkshopSidebar";
import { WorkshopCanvas } from "./components/WorkshopCanvas";
import { WorkshopModals } from "./components/WorkshopModals";
import { WorkshopFilterModal } from "./components/WorkshopFilterModal";
import { WorkshopOpenFundsModal } from "./components/WorkshopOpenFundsModal";
import { WorkshopExportModal } from "./components/WorkshopExportModal";
import { WorkshopAiChatPanel } from "./components/WorkshopAiChatPanel";

// Utilities
import { Geometry } from "./utils/Geometry";
import { Constants } from "./utils/Constants";

// Hooks
import { useWorkshopInteractions } from "./utils/Interactions";
import { useEntityActions } from "./utils/useEntityActions";
import { useLayoutActions } from "./utils/useLayoutActions";
import { useCommentActions } from "./utils/useCommentActions";
import { useUIActions } from "./utils/useUIActions";
import { salesNodePresentation } from "./utils/SalesDesign";
import { Export } from "./utils/Export";

function initialLayoutStructureFromStorage() {
    const valid = new Set(["default", "hierarchical", "circular", "orthogonal", "sales"]);
    try {
        if (typeof localStorage === "undefined") return "default";
        const raw = localStorage.getItem("jigsaw.layoutStructure");
        const m = String(raw || "default").trim().toLowerCase();
        return valid.has(m) ? m : "default";
    } catch (_e) {
        return "default";
    }
}

export class JigsawWorkshop extends Component {
    static template = "jigsaw.Workshop";
    static components = {
        WorkshopHeader,
        WorkshopSidebar,
        WorkshopCanvas,
        WorkshopModals,
        WorkshopFilterModal,
        WorkshopOpenFundsModal,
        WorkshopExportModal,
        WorkshopAiChatPanel,
    };

    setup() {
        // ── Services ──────────────────────────────────────────────────────────
        this.action = useService("action");
        this.orm = useService("orm");
        this.notification = useService("notification");

        // ── Shared Reactive State ─────────────────────────────────────────────
        this.state = useState({
            nodes: [],
            links: [],
            layout: {},
            layoutRevision: 0,
            loading: true,
            zoom: Constants.DEFAULT_ZOOM,
            offsetX: Constants.DEFAULT_OFFSET_X,
            offsetY: Constants.DEFAULT_OFFSET_Y,
            selectedNodeIds: [],
            activeSidebar: null,          // 'data' | 'comments' | null (closed until Data tool or node select)
            isSaving: false,
            showFilterMenu: false,
            showOwnershipMenu: false,
            ownershipDirection: "down",
            ownershipPctThreshold: 10,
            ownershipPctType: "more",
            ownershipFilterEnabled: false,
            ownershipVisibleNodeIds: [],
            filterText: "",
            filterType: "",
            activeFilters: [],
            comments: [],
            activeDataTab: "properties", // 'properties' | 'relationships' | 'files'
            showCommentInputForNode: null,
            newCommentText: "",
            showResolvedComments: false,
            showAllComments: true,
            contextMenu: { visible: false, x: 0, y: 0, nodeId: null, activeMenu: null },
            linkingNodeId: null,
            linkingMode: null,           // 'parent' | 'child'
            editingNode: null,
            editingLink: null,
            showPdfViewer: false,
            hasAiImage: false,
            aiImageFilename: "",
            ocrText: "",
            ocrRunning: false,
            ocrSearch: "",
            filterRules: [],
            filterRulesMode: "all", // 'all' (AND) | 'any' (OR)
            showFilterModal: false,
            // ── Right sidebar resizing ────────────────────────────────────
            sidebarWidth: parseInt(localStorage.getItem("jigsaw.sidebarWidth") || "460", 10),
            importing: false,
            layoutStructure: initialLayoutStructureFromStorage(),
            showLayoutMenu: false,
            // ── Open funds picker (multi-select) ─────────────────────────
            showOpenFundsModal: false,
            openFundsList: [],
            openFundsLoading: false,
            openFundsQuery: "",
            openFundsSelected: {},
            showExportModal: false,
            showAiChatPanel: false,
            aiChatMessages: [],
            aiChatSending: false,
            diagramName: "",
        });

        // ── Refs & Diagram ID ─────────────────────────────────────────────────
        this.canvasRef = useRef("canvas");
        this.fileInputRef = useRef("aiImportFileInput");
        const rawId =
            this.props.action.params?.diagram_id ||
            this.props.action.context?.active_id ||
            this.props.action.context?.default_diagram_id ||
            this.props.action.res_id;
        this.diagramId = rawId ? parseInt(rawId) : null;

        // ── Hook: UI Actions ──────────────────────────────────────────────────
        // Initialised first because entity/layout hooks depend on isNodeFilteredOut
        const ui = useUIActions(this.state, {
            action: this.action,
            notification: this.notification,
        });
        Object.assign(this, ui);

        // ── Hook: Layout Actions ──────────────────────────────────────────────
        // Depends on isNodeFilteredOut from ui and saveLayout from entity (deferred via lambda)
        const layout = useLayoutActions(
            this.state,
            this.canvasRef,
            () => this.saveLayout(),          // deferred: saveLayout defined after entity hook
            (node) => this.isNodeFilteredOut(node)
        );
        Object.assign(this, layout);

        // ── Hook: Entity & Link Actions ───────────────────────────────────────
        const entity = useEntityActions(
            this.state,
            { orm: this.orm, action: this.action, notification: this.notification },
            this.diagramId,
            () => this.treeLayout()           // callback provided to ensureDefaultLayout
        );
        Object.assign(this, entity);

        // ── Hook: Comment Actions ─────────────────────────────────────────────
        const comments = useCommentActions(this.state);
        Object.assign(this, comments);

        // ── Lifecycle ─────────────────────────────────────────────────────────
        onWillStart(async () => {
            await this.ensureDiagramId();
            await this.loadData();
        });

        onMounted(() => {
            this.cleanupInteractions = useWorkshopInteractions(this.canvasRef, this.state, {
                onCreateLink: (id) => this.onCreateLink(id),
                updateOwnershipFilter: () => this.updateOwnershipFilter(),
                saveLayout: () => this.saveLayout(),
                onEditEntity: (id) => this.onEditEntity(id),
                onEditLink: (id) => this.onEditLink(id),
                notify: (msg, type) => this.notification.add(msg, { type }),
            });
        });

        onWillUnmount(() => {
            if (this.cleanupInteractions) this.cleanupInteractions();
        });
    }

    /** Layout dropdown actions (class methods — reliable `this` from workshop template). */
    layoutPickBalanced() {
        this.setLayoutStructure("default");
    }
    layoutPickHierarchical() {
        this.setLayoutStructure("hierarchical");
    }
    layoutPickCircular() {
        this.setLayoutStructure("circular");
    }
    layoutPickOrthogonal() {
        this.setLayoutStructure("orthogonal");
    }
    openExportModal() {
        this.state.showExportModal = true;
    }

    closeExportModal() {
        this.state.showExportModal = false;
    }

    runExportStyledExcel() {
        if (!this.state.nodes.length) {
            this.notification.add("No entities to export.", { type: "warning" });
            this.closeExportModal();
            return;
        }
        Export.exportStyledWorkbook(this.state, (n, s) => this.isNodeFilteredOut(n, s), {
            diagramId: this.diagramId,
        });
        this.notification.add("Excel report downloaded.", { type: "success" });
        this.closeExportModal();
    }

    runExportDiagramPdf() {
        if (!this.state.nodes.length) {
            this.notification.add("No diagram to export.", { type: "warning" });
            this.closeExportModal();
            return;
        }
        Export.openDiagramPrintView(this.state, { diagramId: this.diagramId });
        this.notification.add("Use Print → Save as PDF in the new tab.", { type: "info" });
        this.closeExportModal();
    }

    toggleAiChatPanel() {
        this.state.showAiChatPanel = !this.state.showAiChatPanel;
        if (this.state.showAiChatPanel) {
            this.state.showPdfViewer = false;
            this.state.activeSidebar = null;
        }
    }

    closeAiChatPanel() {
        this.state.showAiChatPanel = false;
    }

    clearAiChatThread() {
        this.state.aiChatMessages = [];
    }

    async sendAiChatMessage(text) {
        const trimmed = (text || "").trim();
        if (!trimmed || !this.diagramId || this.state.aiChatSending) {
            return;
        }
        const history = (this.state.aiChatMessages || []).map((m) => ({
            role: m.role,
            text: m.text,
        }));
        const userMsg = {
            id: `u-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
            role: "user",
            text: trimmed,
        };
        this.state.aiChatMessages = [...this.state.aiChatMessages, userMsg];
        this.state.aiChatSending = true;
        try {
            const res = await this.orm.call("jigsaw.diagram", "action_gemini_fund_chat", [
                this.diagramId,
                trimmed,
                history,
            ]);
            const reply = (res && res.reply) || "";
            this.state.aiChatMessages = [
                ...this.state.aiChatMessages,
                {
                    id: `a-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
                    role: "assistant",
                    text: reply || "—",
                },
            ];
        } catch (e) {
            console.error(e);
            const msg =
                (e && e.data && e.data.message) || (e && e.message) || "Chat request failed.";
            this.state.aiChatMessages = [
                ...this.state.aiChatMessages,
                {
                    id: `e-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
                    role: "assistant",
                    text: typeof msg === "string" ? msg : "Could not reach the assistant. Check Gemini settings.",
                },
            ];
            this.notification.add("AI chat failed — check Gemini API key in Settings.", { type: "danger" });
        } finally {
            this.state.aiChatSending = false;
        }
    }

    layoutPickSales() {
        this.setLayoutStructure("sales");
    }

    getSalesMeta(node) {
        return salesNodePresentation(node, this.state);
    }

    // ── Geometry (pass-through) ───────────────────────────────────────────────

    getLinkPath(link) {
        const info = this.getLinkInfo(link);
        return info ? info.d : "";
    }

    getLinkInfo(link) {
        return Geometry.getLinkInfo(link, this.state);
    }

    get aiImageUrl() {
        if (!this.diagramId || !this.state.hasAiImage) return "";
        return `/web/image/jigsaw.diagram/${this.diagramId}/ai_source_image?unique=${this.diagramId}`;
    }

    get aiSourceContentUrl() {
        if (!this.diagramId || !this.state.hasAiImage) return "";
        const fname = encodeURIComponent(this.state.aiImageFilename || "source");
        // Use Odoo's standard /web/content pattern with `?filename=` (matches
        // the way the built-in FileViewer constructs URLs for ir.binary fields).
        return `/web/content/jigsaw.diagram/${this.diagramId}/ai_source_image?filename=${fname}&unique=${this.diagramId}`;
    }

    get aiImageDownloadUrl() {
        if (!this.aiSourceContentUrl) return "";
        return `${this.aiSourceContentUrl}&download=true`;
    }

    get aiImageIsPdf() {
        return (this.state.aiImageFilename || "").toLowerCase().endsWith(".pdf");
    }

    get pdfViewerUrl() {
        if (!this.aiImageIsPdf || !this.aiSourceContentUrl) return "";
        // Match Odoo's built-in FileViewer URL format exactly:
        //   viewer.html?file=<encoded_route>#pagemode=none
        // `pagemode=none` hides the sidebar so the document fills the panel,
        // mirroring how the chatter PDF viewer renders.
        const file = encodeURIComponent(this.aiSourceContentUrl);
        return `/web/static/lib/pdfjs/web/viewer.html?file=${file}#pagemode=none`;
    }

    get ocrLines() {
        const text = this.state.ocrText || "";
        if (!text) return [];
        const q = (this.state.ocrSearch || "").trim().toLowerCase();
        const lines = text.split(/\r?\n/);
        if (!q) return lines.map((line, i) => ({ i, line, match: false }));
        return lines
            .map((line, i) => ({ i, line, match: line.toLowerCase().includes(q) }))
            .filter((x) => x.match);
    }

    async ensureDiagramId() {
        if (this.diagramId) return;
        try {
            const rows = await this.orm.searchRead(
                "jigsaw.diagram",
                [],
                ["id"],
                { limit: 1, order: "id desc" }
            );
            if (rows && rows.length) {
                this.diagramId = rows[0].id;
            }
        } catch (e) {
            console.error("Failed to resolve default diagram:", e);
        }
    }

    openEntityForm(entityId) {
        if (!entityId) return;
        const node = this.state.nodes.find((n) => n.id === entityId);
        const title = node && node.name ? `Update the Entity · ${node.name}` : "Update the Entity";
        this.action.doAction(
            {
                type: "ir.actions.act_window",
                name: title,
                res_model: "jigsaw.entity",
                res_id: entityId,
                views: [[false, "form"]],
                target: "new",
            },
            { onClose: () => this.loadData() }
        );
    }

    // ── Import Fund Map (one-click image → workshop flow) ─────────────
    triggerImportPicker() {
        const input = this.fileInputRef.el;
        if (input) {
            input.value = ""; // reset so picking the same file twice still fires change
            input.click();
        }
    }

    async onImportFileChosen(ev) {
        const file = ev.target.files && ev.target.files[0];
        if (!file) return;
        if (file.size > 15 * 1024 * 1024) {
            this.notification.add("File is larger than 15 MB. Please use a smaller image/PDF.", { type: "warning" });
            return;
        }

        this.state.importing = true;
        try {
            const b64 = await this._readAsBase64(file);
            const result = await this.orm.call(
                "jigsaw.diagram",
                "create_from_image_payload",
                [b64, file.name, ""],
            );
            if (result && result.diagram_id) {
                this.notification.add(`Imported "${result.name}" — opening...`, { type: "success" });
                // Jump straight into the new diagram's workshop
                await this.action.doAction({
                    type: "ir.actions.client",
                    tag: "jigsaw.workshop",
                    params: { diagram_id: result.diagram_id },
                    target: "current",
                });
            }
        } catch (e) {
            console.error(e);
            const msg = (e && e.data && e.data.message) || (e && e.message) || "Import failed.";
            this.notification.add(`Import failed: ${msg}`, { type: "danger" });
        } finally {
            this.state.importing = false;
        }
    }

    _readAsBase64(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onerror = () => reject(reader.error);
            reader.onload = () => {
                // `result` looks like "data:<mime>;base64,XXXX..." — strip the prefix.
                const dataUrl = reader.result || "";
                const idx = dataUrl.indexOf(",");
                resolve(idx >= 0 ? dataUrl.slice(idx + 1) : dataUrl);
            };
            reader.readAsDataURL(file);
        });
    }

    async runOcr() {
        if (!this.diagramId || this.state.ocrRunning) return;
        this.state.ocrRunning = true;
        try {
            const result = await this.orm.call(
                "jigsaw.diagram",
                "action_run_ocr",
                [this.diagramId],
            );
            this.state.ocrText = (result && result.ocr_text) || "";
            this.notification.add("Text extracted from document.", { type: "success" });
        } catch (e) {
            console.error(e);
            this.notification.add("OCR failed. Check Gemini API key.", { type: "danger" });
        } finally {
            this.state.ocrRunning = false;
        }
    }

    // ── Open fund(s) from header picker ────────────────────────────────────

    closeOpenFundsModal() {
        this.state.showOpenFundsModal = false;
    }

    async openFundsPicker() {
        this.state.showOpenFundsModal = true;
        this.state.openFundsLoading = true;
        this.state.openFundsSelected = {};
        this.state.openFundsQuery = "";
        try {
            const rows = await this.orm.searchRead(
                "jigsaw.diagram",
                [],
                ["id", "name", "create_date"],
                { order: "create_date desc", limit: 200 },
            );
            this.state.openFundsList = (rows || []).map((r) => ({
                id: r.id,
                name: (r.name && String(r.name).trim()) || `Fund #${r.id}`,
                create_date: this._formatDiagramListDate(r.create_date),
            }));
        } catch (e) {
            console.error(e);
            this.notification.add("Could not load funds.", { type: "danger" });
            this.state.openFundsList = [];
        } finally {
            this.state.openFundsLoading = false;
        }
    }

    _formatDiagramListDate(val) {
        if (!val) return "";
        if (typeof val === "string") return val.replace("T", " ").slice(0, 16);
        return String(val).slice(0, 16);
    }

    toggleOpenFundSelect(id) {
        const sid = String(id);
        const next = { ...this.state.openFundsSelected };
        if (next[sid]) {
            delete next[sid];
        } else {
            next[sid] = true;
        }
        this.state.openFundsSelected = next;
    }

    selectAllOpenFundsVisible(select) {
        const q = (this.state.openFundsQuery || "").trim().toLowerCase();
        const list = this.state.openFundsList || [];
        const visible = !q ? list : list.filter((f) => (f.name || "").toLowerCase().includes(q));
        const next = { ...this.state.openFundsSelected };
        for (const f of visible) {
            const sid = String(f.id);
            if (select) {
                next[sid] = true;
            } else {
                delete next[sid];
            }
        }
        this.state.openFundsSelected = next;
    }

    clearOpenFundsSelection() {
        this.state.openFundsSelected = {};
    }

    async confirmOpenSelectedFunds() {
        const sel = this.state.openFundsSelected || {};
        const ids = Object.keys(sel)
            .filter((k) => sel[k])
            .map((k) => parseInt(k, 10))
            .filter((n) => Number.isFinite(n) && n > 0);
        if (!ids.length) {
            this.notification.add("Select at least one fund.", { type: "warning" });
            return;
        }
        this.state.showOpenFundsModal = false;
        const base = { type: "ir.actions.client", tag: "jigsaw.workshop" };
        await this.action.doAction({ ...base, params: { diagram_id: ids[0] }, target: "current" });
        for (let i = 1; i < ids.length; i++) {
            await new Promise((r) => setTimeout(r, 200));
            await this.action.doAction({ ...base, params: { diagram_id: ids[i] }, target: "new" });
        }
        if (ids.length > 1) {
            this.notification.add(`Opened ${ids.length} fund maps (first in this tab).`, { type: "info" });
        }
    }
}

registry.category("actions").add("jigsaw.workshop", JigsawWorkshop);
