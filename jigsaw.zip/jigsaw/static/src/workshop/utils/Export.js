/** @odoo-module **/

import { FilterSchema } from "./FilterSchema";
import { Constants } from "./Constants";

/**
 * Export — turns the in-memory diagram nodes into a downloadable CSV.
 *
 * The CSV is schema-driven: the column list is derived from `FilterSchema`
 * (which mirrors the PE/VC fields exposed by `get_diagram_data`), prefixed
 * with the core identity columns. Selection values are resolved to their
 * human-readable labels and booleans to "Yes"/"No".
 *
 * The file is emitted with a UTF-8 BOM so Excel opens it correctly.
 */

const IDENTITY_COLUMNS = [
    { key: "name",                 label: "Entity Name" },
    { key: "type",                 label: "Shape Type",            type: "selection" },
    { key: "subtype",              label: "Subtype" },
    { key: "jurisdiction",         label: "Jurisdiction" },
    { key: "country",              label: "Country" },
    { key: "registration_no",      label: "Registration No" },
    { key: "entity_id_external",   label: "External Entity ID" },
    { key: "tax_id_number",        label: "Tax ID" },
    { key: "registered_office",    label: "Registered Office" },
    { key: "formation_date",       label: "Formation Date",        type: "date" },
    { key: "fund_family_name",     label: "Fund Family" },
];

function _resolveLabel(field, raw) {
    if (raw === null || raw === undefined) return "";

    if (field.type === "boolean") {
        return raw ? "Yes" : "No";
    }

    if (field.type === "selection") {
        const opts = field.options || FilterSchema.findField(field._cat, field.key)?.options;
        if (opts) {
            const hit = opts.find((o) => o.value === raw);
            if (hit) return hit.label;
        }
        // Fallback to identity-column selection lookup (e.g. shape type)
        const ident = IDENTITY_COLUMNS.find((c) => c.key === field.key);
        if (ident) {
            const idCat = FilterSchema.categories.find((cat) =>
                cat.fields.some((f) => f.key === field.key)
            );
            if (idCat) {
                const f = idCat.fields.find((f) => f.key === field.key);
                const hit = f && (f.options || []).find((o) => o.value === raw);
                if (hit) return hit.label;
            }
        }
    }

    if (field.type === "number") {
        if (raw === 0 || raw === "0") return "0";
        return String(raw);
    }

    return String(raw);
}

function _csvEscape(value) {
    const s = value === null || value === undefined ? "" : String(value);
    // Always quote to be safe with commas, newlines, embedded quotes
    return `"${s.replace(/"/g, '""')}"`;
}

function _buildColumns() {
    const cols = IDENTITY_COLUMNS.map((c) => ({ ...c }));
    for (const cat of FilterSchema.categories) {
        for (const f of cat.fields) {
            // Skip identity duplicates (e.g. "type", "jurisdiction" are already in identity)
            if (cols.some((c) => c.key === f.key)) continue;
            cols.push({
                key: f.key,
                label: `${cat.label} — ${f.label}`,
                type: f.type,
                options: f.options,
                _cat: cat.key,
            });
        }
    }
    return cols;
}

function _htmlCell(value) {
    const s = value === null || value === undefined ? "" : String(value);
    return s
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/\r?\n/g, " ");
}

function _buildColumnGroups() {
    const all = _buildColumns();
    const identity = all.filter((c) => !c._cat);
    const groups = [{ title: "Core identity", cols: identity }];
    for (const cat of FilterSchema.categories) {
        const cols = all.filter((c) => c._cat === cat.key);
        if (cols.length) {
            groups.push({ title: cat.label, cols });
        }
    }
    return groups;
}

const XLS_STYLES = {
    title:
        "background:#502D7F;color:#e8c86e;font-weight:bold;font-size:16px;padding:10px 12px;text-align:center;border:1px solid #3d2460;",
    subtitle:
        "background:#ece8f2;color:#502D7F;padding:8px 12px;font-size:12px;border:1px solid #beb3d1;",
    groupHdr:
        "background:#5c4082;color:#e8c86e;font-weight:bold;font-size:13px;padding:8px 10px;border:1px solid #502D7F;",
    th: "background:#d4cde5;color:#3d2460;font-weight:600;font-size:11px;padding:6px 8px;border:1px solid #beb3d1;",
    td: "background:#f7f5fa;color:#2d1f45;font-size:11px;padding:5px 8px;border:1px solid #e0dae8;",
    tdAlt: "background:#ffffff;color:#2d1f45;font-size:11px;padding:5px 8px;border:1px solid #e0dae8;",
    linkHdr:
        "background:#3d2460;color:#e8c86e;font-weight:bold;font-size:13px;padding:8px 10px;border:1px solid #2d1f45;",
};

function _linksTableFragment(state) {
    const RT = Constants.RELATIONSHIP_TYPES || {};
    const links = state.links || [];
    if (!links.length) return "";

    let rows = `<tr><td colspan="5" style="${XLS_STYLES.linkHdr}">Relationships</td></tr>`;
    rows += `<tr>
<td style="${XLS_STYLES.th}">From (entity)</td>
<td style="${XLS_STYLES.th}">To (entity)</td>
<td style="${XLS_STYLES.th}">Type</td>
<td style="${XLS_STYLES.th}">%</td>
<td style="${XLS_STYLES.th}">Link id</td>
</tr>`;

    const nameOf = (id) => {
        const n = state.nodes.find((x) => String(x.id) === String(id));
        return n ? n.name : String(id);
    };

    links.forEach((link, i) => {
        const typeInfo = RT[link.type] || RT.default || { label: link.type || "LINK" };
        const rawPct = link.percent ?? link.ownership_pct;
        const pct = rawPct !== undefined && rawPct !== null ? String(rawPct) : "";
        const rowStyle = i % 2 ? XLS_STYLES.tdAlt : XLS_STYLES.td;
        rows += `<tr>
<td style="${rowStyle}">${_htmlCell(nameOf(link.source))}</td>
<td style="${rowStyle}">${_htmlCell(nameOf(link.target))}</td>
<td style="${rowStyle}">${_htmlCell(typeInfo.label)}</td>
<td style="${rowStyle}">${_htmlCell(pct)}</td>
<td style="${rowStyle}">${_htmlCell(link.id != null ? String(link.id) : "")}</td>
</tr>`;
    });

    return `<table style="border-collapse:collapse;margin-bottom:20px;width:100%;max-width:1200px;">${rows}</table>`;
}

export const Export = {
    /**
     * Grouped HTML tables (purple / gold) saved as .xls for Excel.
     */
    exportStyledWorkbook(state, isNodeFilteredOut, meta) {
        if (!state.nodes || !state.nodes.length) return;

        const visible = state.nodes.filter((n) => !isNodeFilteredOut(n, state));
        if (!visible.length) return;

        const groups = _buildColumnGroups();
        const layout = state.layoutStructure || "default";
        const diagramPart = meta && meta.diagramId ? `Diagram #${meta.diagramId} · ` : "";

        let html = `<!DOCTYPE html><html><head><meta charset="utf-8"/></head><body style="font-family:Calibri,Segoe UI,sans-serif">`;
        html += `<table style="border-collapse:collapse;margin-bottom:12px;width:100%;max-width:1200px;"><tr><td style="${XLS_STYLES.title}">PurpleMaps — Entity export</td></tr>`;
        html += `<tr><td style="${XLS_STYLES.subtitle}">${diagramPart}Exported ${new Date().toLocaleString()} · Layout: ${_htmlCell(layout)} · ${visible.length} entities</td></tr></table>`;

        html += _linksTableFragment(state);

        for (const g of groups) {
            if (!g.cols.length) continue;
            const colCount = g.cols.length;
            html += `<table style="border-collapse:collapse;margin-bottom:24px;width:100%;max-width:1200px;">`;
            html += `<tr><td colspan="${colCount}" style="${XLS_STYLES.groupHdr}">${_htmlCell(g.title)}</td></tr><tr>`;
            for (const c of g.cols) {
                html += `<td style="${XLS_STYLES.th}">${_htmlCell(c.label)}</td>`;
            }
            html += `</tr>`;
            visible.forEach((node, ri) => {
                const rowStyle = ri % 2 ? XLS_STYLES.tdAlt : XLS_STYLES.td;
                html += `<tr>`;
                for (const c of g.cols) {
                    const raw = node[c.key];
                    html += `<td style="${rowStyle}">${_htmlCell(_resolveLabel(c, raw))}</td>`;
                }
                html += `</tr>`;
            });
            html += `</table>`;
        }

        html += `</body></html>`;

        const blob = new Blob([html], { type: "application/vnd.ms-excel;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const today = new Date().toISOString().slice(0, 10);
        const a = document.createElement("a");
        a.href = url;
        a.download = `PurpleMaps_Report_${today}.xls`;
        a.style.visibility = "hidden";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(() => URL.revokeObjectURL(url), 1500);
    },

    /**
     * Opens the current SVG map in a new tab with a print button (Save as PDF from the browser).
     */
    openDiagramPrintView(state, meta) {
        const svgEl = document.querySelector(".jigsaw-workshop .jigsaw-svg-canvas");
        if (!svgEl) return;

        // In the workshop, the SVG is only sized via CSS (100% of a 10k×10k layer). The print tab
        // does not load workshop SCSS, so a raw serialized <svg> often collapses to zero height and
        // looks blank. Clone, attach a real viewBox + pixel dimensions from content bounds.
        let bbox = null;
        try {
            bbox = svgEl.getBBox();
        } catch (_e) {
            bbox = null;
        }
        const pad = 64;
        let vbX;
        let vbY;
        let vbW;
        let vbH;
        if (
            bbox &&
            Number.isFinite(bbox.width) &&
            Number.isFinite(bbox.height) &&
            bbox.width > 2 &&
            bbox.height > 2
        ) {
            vbX = bbox.x - pad;
            vbY = bbox.y - pad;
            vbW = bbox.width + pad * 2;
            vbH = bbox.height + pad * 2;
        } else {
            vbX = 0;
            vbY = 0;
            vbW = 1400;
            vbH = 900;
        }

        const clone = svgEl.cloneNode(true);
        clone.removeAttribute("style");
        clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
        clone.setAttribute("viewBox", `${vbX} ${vbY} ${vbW} ${vbH}`);
        clone.setAttribute("width", String(Math.ceil(vbW)));
        clone.setAttribute("height", String(Math.ceil(vbH)));
        clone.setAttribute("preserveAspectRatio", "xMidYMid meet");

        let svgText = new XMLSerializer().serializeToString(clone);
        if (!svgText.includes("xmlns=")) {
            svgText = svgText.replace("<svg", '<svg xmlns="http://www.w3.org/2000/svg"');
        }

        const w = window.open("", "_blank");
        if (!w) return;

        const title =
            meta && meta.diagramId
                ? `PurpleMaps Diagram #${meta.diagramId}`
                : "PurpleMaps Diagram";
        const layout = state.layoutStructure || "default";

        w.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"/><title>${title}</title>
<style>
body { margin:0; padding:16px; font-family:system-ui,sans-serif; background:#fafafa; }
h1 { color:#502D7F; font-size:18px; margin:0 0 4px; }
.meta { color:#64748b; font-size:12px; margin-bottom:12px; }
.wrap { background:#fff; padding:12px; border-radius:12px; box-shadow:0 1px 3px rgba(0,0,0,.08); display:block; width:100%; box-sizing:border-box; max-width:100%; }
.wrap svg { width:100% !important; max-width:100%; height:auto !important; display:block; }
.node-text-name { fill:#0f172a; font-size:13px; font-weight:600; font-family:Inter,system-ui,sans-serif; }
.node-text-type { fill:#1e40af; font-size:9px; font-weight:700; letter-spacing:0.08em; font-family:Inter,system-ui,sans-serif; }
.node-text-jurisdiction, .node-text-jur { fill:#64748b; font-size:11px; font-family:Inter,system-ui,sans-serif; }
.btn-print { margin:12px 0; padding:10px 20px; background:#502D7F; color:#e8c86e; border:none; border-radius:10px; font-weight:bold; cursor:pointer; font-size:14px; }
.btn-print:hover { filter:brightness(1.05); }
@media print {
  body { background:#fff; padding:0; }
  .no-print { display:none !important; }
  @page { size: landscape; margin: 10mm; }
}
</style></head><body>
<p class="no-print meta">Choose <strong>Print</strong>, then select <strong>Save as PDF</strong> as the destination if you want a PDF file.</p>
<button type="button" class="no-print btn-print" onclick="window.print()">Print / Save as PDF</button>
<h1>${title}</h1>
<div class="meta">${layout} layout · ${state.nodes.length} entities · ${new Date().toLocaleString()}</div>
<div class="wrap">${svgText}</div>
</body></html>`);
        w.document.close();
    },

    exportExcel(state, isNodeFilteredOut) {
        if (!state.nodes || !state.nodes.length) return;

        const columns = _buildColumns();
        const lines = [];

        // Header
        lines.push(columns.map((c) => _csvEscape(c.label)).join(","));

        // Rows
        for (const node of state.nodes) {
            if (isNodeFilteredOut(node, state)) continue;
            const row = columns.map((c) => {
                const raw = node[c.key];
                return _csvEscape(_resolveLabel(c, raw));
            });
            lines.push(row.join(","));
        }

        // UTF-8 BOM so Excel reads it with the right encoding
        const bom = "\uFEFF";
        const csv = bom + lines.join("\r\n");
        const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);

        const today = new Date().toISOString().slice(0, 10);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", `PurpleMaps_Entities_${today}.csv`);
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    },
};
