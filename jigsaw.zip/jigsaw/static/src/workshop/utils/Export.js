/** @odoo-module **/

import { FilterSchema } from "./FilterSchema";

/**
 * Export — turns the in-memory diagram nodes into a downloadable CSV.
 *
 * The CSV is schema-driven: the column list is derived from `FilterSchema`
 * (which mirrors the PE/VC fields exposed by `get_diagram_data`), prefixed
 * with the core identity columns. Selection values are resolved to their
 * human-readable labels and booleans to "Yes"/"No".
 *
 * The file is emitted with a UTF-8 BOM so Excel opens it correctly.
 */

const IDENTITY_COLUMNS = [
    { key: "name",                 label: "Entity Name" },
    { key: "type",                 label: "Shape Type",            type: "selection" },
    { key: "subtype",              label: "Subtype" },
    { key: "jurisdiction",         label: "Jurisdiction" },
    { key: "country",              label: "Country" },
    { key: "registration_no",      label: "Registration No" },
    { key: "entity_id_external",   label: "External Entity ID" },
    { key: "tax_id_number",        label: "Tax ID" },
    { key: "registered_office",    label: "Registered Office" },
    { key: "formation_date",       label: "Formation Date",        type: "date" },
    { key: "fund_family_name",     label: "Fund Family" },
];

function _resolveLabel(field, raw) {
    if (raw === null || raw === undefined) return "";

    if (field.type === "boolean") {
        return raw ? "Yes" : "No";
    }

    if (field.type === "selection") {
        const opts = field.options || FilterSchema.findField(field._cat, field.key)?.options;
        if (opts) {
            const hit = opts.find((o) => o.value === raw);
            if (hit) return hit.label;
        }
        // Fallback to identity-column selection lookup (e.g. shape type)
        const ident = IDENTITY_COLUMNS.find((c) => c.key === field.key);
        if (ident) {
            const idCat = FilterSchema.categories.find((cat) =>
                cat.fields.some((f) => f.key === field.key)
            );
            if (idCat) {
                const f = idCat.fields.find((f) => f.key === field.key);
                const hit = f && (f.options || []).find((o) => o.value === raw);
                if (hit) return hit.label;
            }
        }
    }

    if (field.type === "number") {
        if (raw === 0 || raw === "0") return "0";
        return String(raw);
    }

    return String(raw);
}

function _csvEscape(value) {
    const s = value === null || value === undefined ? "" : String(value);
    // Always quote to be safe with commas, newlines, embedded quotes
    return `"${s.replace(/"/g, '""')}"`;
}

function _buildColumns() {
    const cols = IDENTITY_COLUMNS.map((c) => ({ ...c }));
    for (const cat of FilterSchema.categories) {
        for (const f of cat.fields) {
            // Skip identity duplicates (e.g. "type", "jurisdiction" are already in identity)
            if (cols.some((c) => c.key === f.key)) continue;
            cols.push({
                key: f.key,
                label: `${cat.label} — ${f.label}`,
                type: f.type,
                options: f.options,
                _cat: cat.key,
            });
        }
    }
    return cols;
}

export const Export = {
    exportExcel(state, isNodeFilteredOut) {
        if (!state.nodes || !state.nodes.length) return;

        const columns = _buildColumns();
        const lines = [];

        // Header
        lines.push(columns.map((c) => _csvEscape(c.label)).join(","));

        // Rows
        for (const node of state.nodes) {
            if (isNodeFilteredOut(node, state)) continue;
            const row = columns.map((c) => {
                const raw = node[c.key];
                return _csvEscape(_resolveLabel(c, raw));
            });
            lines.push(row.join(","));
        }

        // UTF-8 BOM so Excel reads it with the right encoding
        const bom = "\uFEFF";
        const csv = bom + lines.join("\r\n");
        const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);

        const today = new Date().toISOString().slice(0, 10);
        const link = document.createElement("a");
        link.setAttribute("href", url);
        link.setAttribute("download", `PurpleMaps_Entities_${today}.csv`);
        link.style.visibility = "hidden";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    },
};
