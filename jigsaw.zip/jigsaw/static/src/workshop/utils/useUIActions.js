/** @odoo-module **/

import { Filtering } from "./Filtering";
import { Export } from "./Export";
import { FilterSchema } from "./FilterSchema";

/**
 * useUIActions — handles sidebar toggling, filter/ownership controls,
 * node selection, and data export for the Jigsaw workshop.
 *
 * @param {object}   state    - OWL reactive state from the parent component
 * @param {object}   services - { action, notification }
 */
export function useUIActions(state, services) {
    const { action } = services;

    // ── Navigation / App ──────────────────────────────────────────────────────

    function onClose() {
        action.doAction({ type: "ir.actions.act_window_close" });
    }

    // ── Sidebar & Tab Controls ────────────────────────────────────────────────

    function toggleSidebar(sidebar) {
        state.activeSidebar = state.activeSidebar === sidebar ? null : sidebar;
        if (state.activeSidebar && state.showAiChatPanel) {
            state.showAiChatPanel = false;
        }
    }

    function toggleDataTab(tab) {
        state.activeDataTab = tab;
    }

    function onSelectNode(nodeId) {
        state.selectedNodeIds = [nodeId];
    }

    // ── Filter Controls ───────────────────────────────────────────────────────

    function isNodeFilteredOut(node) {
        return Filtering.isNodeFilteredOut(node, state);
    }

    function isLinkFilteredOut(link) {
        return Filtering.isLinkFilteredOut(link, state);
    }

    function toggleFilter(filter) {
        const idx = state.activeFilters.indexOf(filter);
        if (idx > -1) {
            state.activeFilters.splice(idx, 1);
        } else {
            state.activeFilters.push(filter);
        }
    }

    // ── Ownership Filter ──────────────────────────────────────────────────────

    function toggleOwnershipMenu() {
        state.showOwnershipMenu = !state.showOwnershipMenu;
        if (state.showOwnershipMenu) {
            updateOwnershipFilter();
        }
    }

    function setOwnershipDirection(dir) {
        state.ownershipDirection = dir;
        updateOwnershipFilter();
    }

    function clearOwnershipFilter() {
        state.ownershipVisibleNodeIds = [];
        state.showOwnershipMenu = false;
    }

    function updateOwnershipFilter() {
        state.ownershipVisibleNodeIds = Filtering.updateOwnershipFilter(state);
    }

    // ── Modal Helpers ─────────────────────────────────────────────────────────

    function onCloseEntityModal() {
        state.editingNode = null;
    }

    function onCloseLinkModal() {
        state.editingLink = null;
    }

    function togglePdfViewer() {
        state.showPdfViewer = !state.showPdfViewer;
        if (state.showPdfViewer && state.showAiChatPanel) {
            state.showAiChatPanel = false;
        }
    }

    // ── Advanced Filter Modal ─────────────────────────────────────────────────
    function openFilterModal() {
        state.showFilterModal = true;
        // Seed with a starter rule if user hasn't added any yet, so the popup
        // never looks empty on first open.
        if (!state.filterRules || state.filterRules.length === 0) {
            addFilterRule();
        }
    }

    function closeFilterModal() {
        state.showFilterModal = false;
    }

    function toggleFilterModal() {
        if (state.showFilterModal) {
            closeFilterModal();
        } else {
            openFilterModal();
        }
    }

    // ── Advanced Filter Rules ─────────────────────────────────────────────────
    function _newRuleId() {
        return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    }

    function addFilterRule() {
        if (!state.filterRules) state.filterRules = [];
        state.filterRules.push({
            id: _newRuleId(),
            category: "",
            field: "",
            type: "",
            operator: "",
            value: "",
            enabled: true,
        });
    }

    function removeFilterRule(id) {
        state.filterRules = (state.filterRules || []).filter((r) => r.id !== id);
    }

    function clearFilterRules() {
        state.filterRules = [];
    }

    function toggleFilterRule(id) {
        const rule = (state.filterRules || []).find((r) => r.id === id);
        if (rule) rule.enabled = !rule.enabled;
    }

    function setFilterRuleCategory(id, categoryKey) {
        const rule = (state.filterRules || []).find((r) => r.id === id);
        if (!rule) return;
        rule.category = categoryKey;
        rule.field = "";
        rule.type = "";
        rule.operator = "";
        rule.value = "";
    }

    function setFilterRuleField(id, fieldKey) {
        const rule = (state.filterRules || []).find((r) => r.id === id);
        if (!rule) return;
        const fieldDef = FilterSchema.findField(rule.category, fieldKey);
        rule.field = fieldKey;
        rule.type = fieldDef ? fieldDef.type : "";
        const ops = FilterSchema.operatorsFor(rule.type);
        rule.operator = ops.length ? ops[0].value : "";
        rule.value = rule.type === "boolean" ? "" : "";
    }

    function setFilterRuleOperator(id, operator) {
        const rule = (state.filterRules || []).find((r) => r.id === id);
        if (rule) rule.operator = operator;
    }

    function setFilterRuleValue(id, value) {
        const rule = (state.filterRules || []).find((r) => r.id === id);
        if (rule) rule.value = value;
    }

    function setFilterRulesMode(mode) {
        state.filterRulesMode = mode === "any" ? "any" : "all";
    }

    function toggleLayoutMenu() {
        state.showLayoutMenu = !state.showLayoutMenu;
    }

    // ── Export ────────────────────────────────────────────────────────────────

    function exportExcel() {
        Export.exportExcel(state, (node, s) => Filtering.isNodeFilteredOut(node, s));
    }

    return {
        onClose,
        toggleSidebar,
        toggleDataTab,
        onSelectNode,
        isNodeFilteredOut,
        isLinkFilteredOut,
        toggleFilter,
        toggleOwnershipMenu,
        setOwnershipDirection,
        clearOwnershipFilter,
        updateOwnershipFilter,
        onCloseEntityModal,
        onCloseLinkModal,
        togglePdfViewer,
        openFilterModal,
        closeFilterModal,
        toggleFilterModal,
        addFilterRule,
        removeFilterRule,
        clearFilterRules,
        toggleFilterRule,
        setFilterRuleCategory,
        setFilterRuleField,
        setFilterRuleOperator,
        setFilterRuleValue,
        setFilterRulesMode,
        exportExcel,
        toggleLayoutMenu,
    };
}
