/** @odoo-module **/

import { Constants } from "./Constants";

const RING_R = 34;
const RING_CIRC = 2 * Math.PI * RING_R;

function _incomingLinks(state, nodeId) {
    const tid = Number(nodeId);
    return (state.links || []).filter((l) => Number(l.target) === tid);
}

/** 0–100 for donut ring (default 100 for roots). */
export function salesDonutPct(node, state) {
    const incoming = _incomingLinks(state, node.id);
    if (!incoming.length) return 100;
    const raw = Number.parseFloat(incoming[0].percent ?? incoming[0].ownership_pct);
    if (Number.isFinite(raw)) return Math.min(100, Math.max(0, raw));
    return 80;
}

/** Labels and SVG dasharray for Sales card nodes. */
export function salesNodePresentation(node, state) {
    const pct = salesDonutPct(node, state);
    const dash = (pct / 100) * RING_CIRC;
    const name = (node.name || "?").trim();
    const iconLetter = name ? name.charAt(0).toUpperCase() : "?";
    const incoming = _incomingLinks(state, node.id);
    const typeKey = incoming[0]?.type || "default";
    const rel = Constants.RELATIONSHIP_TYPES[typeKey] || Constants.RELATIONSHIP_TYPES.default;
    const jur = (node.jurisdiction || "").trim();
    const detailLine = jur ? `${rel.label} · ${pct}% · ${jur}` : `${rel.label} · ${pct}%`;
    return {
        pct,
        ringDash: `${dash} ${RING_CIRC}`,
        iconLetter,
        detailLine,
    };
}
