/** @odoo-module **/

import { Constants } from "./Constants";

// Map relationship color → arrowhead marker id
const COLOR_TO_MARKER = {
    '#2563eb': 'blue',
    '#059669': 'green',
    '#7c3aed': 'purple',
    '#6b5694': 'purple',
    '#d97706': 'amber',
    '#4f46e5': 'indigo',
    '#475569': 'slate',
    '#dc2626': 'red',
    '#b91c1c': 'red',
    '#db2777': 'pink',
    '#0d9488': 'teal',
};

export const Geometry = {

    /**
     * Bounding box per node. Pass layoutStyle when positioning Sales cards.
     * Values must match SVG in WorkshopCanvas.xml for non-sales shapes.
     */
    nodeGeometry(node, layoutStyle) {
        if (layoutStyle === "sales") {
            const c = Constants.SALES_CARD;
            return { w: c.w, h: c.h, cx: c.cx, cy: c.cy, topY: c.topY, botY: c.botY };
        }
        switch (node && node.type) {
            case 'individual':
                // ellipse cx=100 cy=46 rx=100 ry=46
                return { w: 200, h: 92, cx: 100, cy: 46, topY: 0, botY: 92 };
            case 'fund':
                // triangle: apex (110,4) base y=140, width 220
                return { w: 220, h: 140, cx: 110, cy: 90, topY: 30, botY: 140 };
            case 'trust':
                // shield path M 0,0 H 180 V 52 Q 90,90 0,52 Z
                return { w: 180, h: 90, cx: 90, cy: 32, topY: 0, botY: 82 };
            case 'asset':
                // diamond polygon 110,0 220,60 110,120 0,60
                return { w: 220, h: 120, cx: 110, cy: 60, topY: 0, botY: 120 };
            case 'gov':
                return { w: 180, h: 72, cx: 90, cy: 36, topY: 0, botY: 72 };
            case 'company':
            default:
                // rect 0,0 → 180,72
                return { w: 180, h: 72, cx: 90, cy: 36, topY: 0, botY: 72 };
        }
    },

    getLinkInfo(link, state) {
        if (!state.layout) return null;

        const sid = String(link.source);
        const tid = String(link.target);
        const sourcePos = state.layout[sid];
        const targetPos = state.layout[tid];
        if (!sourcePos || !targetPos) return null;

        const srcNode = state.nodes.find((n) => String(n.id) === sid);
        const tgtNode = state.nodes.find((n) => String(n.id) === tid);
        if (!srcNode || !tgtNode) return null;

        const srcGeo = this.nodeGeometry(srcNode, state.layoutStructure);
        const tgtGeo = this.nodeGeometry(tgtNode, state.layoutStructure);

        // ── Direction ─────────────────────────────────────────────────────────
        const srcCY = (sourcePos.y || 0) + srcGeo.cy;
        const tgtCY = (targetPos.y || 0) + tgtGeo.cy;
        const goingDown = tgtCY >= srcCY;

        // ── Straight diagonal line from source edge to target edge ─────────────
        //
        // Each link is a SINGLE straight segment from the source node's
        // bottom-center (or top, if going up) directly to the target node's
        // top-center (or bottom). No elbows, no fan-out — so the % label
        // sits clearly along its own line.
        const sx = (sourcePos.x || 0) + srcGeo.cx;
        const sy = (sourcePos.y || 0) + (goingDown ? srcGeo.botY : srcGeo.topY);

        const tx = (targetPos.x || 0) + tgtGeo.cx;
        const ty = (targetPos.y || 0) + (goingDown ? tgtGeo.topY : tgtGeo.botY);

        const dx = tx - sx;
        const dy = ty - sy;
        const len = Math.max(1, Math.sqrt(dx * dx + dy * dy));
        const nxOff = -dy / len;
        const nyOff = dx / len;

        let d;
        let lx;
        let ly;
        let rx;
        let ry;

        const useOrthogonal =
            (state.layoutStructure === "orthogonal" ||
                state.layoutStructure === "hierarchical" ||
                state.layoutStructure === "sales") &&
            Math.abs(sx - tx) >= 3;

        if (useOrthogonal) {
            const midY = (sy + ty) / 2;
            d = `M ${sx} ${sy} L ${sx} ${midY} L ${tx} ${midY} L ${tx} ${ty}`;
            const mx = (sx + tx) / 2;
            lx = Math.round(mx);
            ly = Math.round(midY - 12);
            rx = Math.round(mx);
            ry = Math.round(midY + 16);
        } else {
            d = `M ${sx} ${sy} L ${tx} ${ty}`;
            const mx = (sx + tx) / 2;
            const my = (sy + ty) / 2;
            const PCT_OFFSET = 10;
            lx = Math.round(mx + nxOff * PCT_OFFSET);
            ly = Math.round(my + nyOff * PCT_OFFSET);
            const TYPE_OFFSET = -14;
            rx = Math.round(mx + nxOff * TYPE_OFFSET);
            ry = Math.round(my + nyOff * TYPE_OFFSET);
        }

        const typeInfo = Constants.RELATIONSHIP_TYPES[link.type] || Constants.RELATIONSHIP_TYPES.default;
        const sales = state.layoutStructure === "sales";
        const strokeColor = sales ? Constants.SALES_THEME.linkStroke : typeInfo.color;
        const rawPct = Number.parseFloat(link.percent ?? link.ownership_pct);
        const pctValue = Number.isFinite(rawPct) ? rawPct : 0;
        const pctText = Number.isInteger(pctValue) ? `${pctValue}` : `${pctValue.toFixed(2)}`;

        return {
            d,
            sx, sy,
            lx, ly,
            rx, ry,
            label: sales ? "" : typeInfo.label,
            color: strokeColor,
            markerId: COLOR_TO_MARKER[typeInfo.color] || "slate",
            percent: pctValue,
            percentText: sales ? undefined : pctText,
        };
    },
};
