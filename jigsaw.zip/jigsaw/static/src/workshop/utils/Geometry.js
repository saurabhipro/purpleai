/** @odoo-module **/

import { Constants } from "./Constants";

// Map relationship color → arrowhead marker id
const COLOR_TO_MARKER = {
    '#2563eb': 'blue',
    '#059669': 'green',
    '#7c3aed': 'purple',
    '#d97706': 'amber',
    '#4f46e5': 'indigo',
    '#475569': 'slate',
    '#dc2626': 'red',
    '#b91c1c': 'red',
    '#db2777': 'pink',
    '#0d9488': 'teal',
};

export const Geometry = {

    /**
     * Returns the bounding geometry for a node shape.
     * Values must match the SVG shape dimensions in WorkshopCanvas.xml.
     *   cx / cy  — visual centre (for connection midpoints)
     *   topY     — y where a line entering from the top should connect
     *   botY     — y where a line leaving from the bottom should connect
     *   w / h    — overall bounding box width / height
     */
    nodeGeometry(node) {
        switch (node && node.type) {
            case 'individual':
                // ellipse cx=100 cy=46 rx=100 ry=46
                return { w: 200, h: 92, cx: 100, cy: 46, topY: 0, botY: 92 };
            case 'fund':
                // triangle: apex (110,4) base y=140, width 220
                return { w: 220, h: 140, cx: 110, cy: 90, topY: 30, botY: 140 };
            case 'trust':
                // shield path M 0,0 H 180 V 52 Q 90,90 0,52 Z
                return { w: 180, h: 90, cx: 90, cy: 32, topY: 0, botY: 82 };
            case 'asset':
                // diamond polygon 110,0 220,60 110,120 0,60
                return { w: 220, h: 120, cx: 110, cy: 60, topY: 0, botY: 120 };
            case 'gov':
                return { w: 180, h: 72, cx: 90, cy: 36, topY: 0, botY: 72 };
            case 'company':
            default:
                // rect 0,0 → 180,72
                return { w: 180, h: 72, cx: 90, cy: 36, topY: 0, botY: 72 };
        }
    },

    getLinkInfo(link, state) {
        if (!state.layout) return null;

        const sourcePos = state.layout[link.source.toString()];
        const targetPos = state.layout[link.target.toString()];
        if (!sourcePos || !targetPos) return null;

        const srcNode = state.nodes.find(n => n.id === link.source);
        const tgtNode = state.nodes.find(n => n.id === link.target);
        if (!srcNode || !tgtNode) return null;

        const srcGeo = this.nodeGeometry(srcNode);
        const tgtGeo = this.nodeGeometry(tgtNode);

        // ── Direction ─────────────────────────────────────────────────────────
        const srcCY = (sourcePos.y || 0) + srcGeo.cy;
        const tgtCY = (targetPos.y || 0) + tgtGeo.cy;
        const goingDown = tgtCY >= srcCY;

        // ── Straight diagonal line from source edge to target edge ─────────────
        //
        // Each link is a SINGLE straight segment from the source node's
        // bottom-center (or top, if going up) directly to the target node's
        // top-center (or bottom). No elbows, no fan-out — so the % label
        // sits clearly along its own line.
        const sx = (sourcePos.x || 0) + srcGeo.cx;
        const sy = (sourcePos.y || 0) + (goingDown ? srcGeo.botY : srcGeo.topY);

        const tx = (targetPos.x || 0) + tgtGeo.cx;
        const ty = (targetPos.y || 0) + (goingDown ? tgtGeo.topY : tgtGeo.botY);

        const d = `M ${sx} ${sy} L ${tx} ${ty}`;

        // ── Label positions ────────────────────────────────────────────────────
        // Place % at the midpoint of the line, slightly offset perpendicular
        // to the line so it doesn't sit directly on top of the stroke.
        const mx = (sx + tx) / 2;
        const my = (sy + ty) / 2;
        const dx = tx - sx;
        const dy = ty - sy;
        const len = Math.max(1, Math.sqrt(dx * dx + dy * dy));
        const nxOff = -dy / len;            // perpendicular unit vector x
        const nyOff =  dx / len;            // perpendicular unit vector y

        const PCT_OFFSET = 10;
        const lx = Math.round(mx + nxOff * PCT_OFFSET);
        const ly = Math.round(my + nyOff * PCT_OFFSET);

        const TYPE_OFFSET = -14;
        const rx = Math.round(mx + nxOff * TYPE_OFFSET);
        const ry = Math.round(my + nyOff * TYPE_OFFSET);

        const typeInfo = Constants.RELATIONSHIP_TYPES[link.type] || Constants.RELATIONSHIP_TYPES.default;
        const rawPct = Number.parseFloat(link.percent ?? link.ownership_pct);
        const pctValue = Number.isFinite(rawPct) ? rawPct : 0;
        const pctText = Number.isInteger(pctValue) ? `${pctValue}` : `${pctValue.toFixed(2)}`;

        return {
            d,
            sx, sy,
            lx, ly,
            rx, ry,
            label: typeInfo.label,
            color: typeInfo.color,
            markerId: COLOR_TO_MARKER[typeInfo.color] || 'slate',
            percent: pctValue,
            percentText: pctText,
        };
    },
};
