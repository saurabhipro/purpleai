/** @odoo-module **/

import { Constants } from "./Constants";
import { Geometry } from "./Geometry";

export const Layouts = {
    /**
     * Hierarchical (Sugiyama-style) tree layout.
     *
     *  – Each node is placed on a horizontal "level" row.
     *  – Leaves sit on the bottom row (max level).
     *  – A node is placed just above its lowest child: a root that owns a
     *    single leaf will sit one row above that leaf, not at the very top.
     *  – Within each level, nodes are sorted by the barycenter of their
     *    parents' positions to minimise crossings.
     *  – Levels are then horizontally centred so the diagram looks balanced.
     */
    treeLayout(state) {
        if (!state.nodes || state.nodes.length === 0) return {};

        const childrenOf = new Map();
        const parentsOf  = new Map();
        state.nodes.forEach((n) => {
            childrenOf.set(n.id, []);
            parentsOf.set(n.id, []);
        });
        state.links.forEach((l) => {
            if (childrenOf.has(l.source) && parentsOf.has(l.target)) {
                childrenOf.get(l.source).push(l.target);
                parentsOf.get(l.target).push(l.source);
            }
        });

        // ── Pass 1: longest path from each node to any leaf (bottom-up) ──────
        const longestToLeaf = new Map();
        const onStack = new Set();
        const computeLongest = (id) => {
            if (longestToLeaf.has(id)) return longestToLeaf.get(id);
            if (onStack.has(id)) return 0;
            onStack.add(id);
            let depth = 0;
            for (const c of childrenOf.get(id) || []) {
                depth = Math.max(depth, 1 + computeLongest(c));
            }
            onStack.delete(id);
            longestToLeaf.set(id, depth);
            return depth;
        };
        state.nodes.forEach((n) => computeLongest(n.id));

        const maxDepth = Math.max(0, ...longestToLeaf.values());

        // ── Pass 2: assign a level to every node ─────────────────────────────
        //   • For root nodes (no parents) → level = maxDepth − longestPathToLeaf
        //     so a root whose only descendant is a leaf sits just above it.
        //   • For all other nodes → level = max(parent.level) + 1
        const level = new Map();
        const queue = [];
        state.nodes.forEach((n) => {
            const parents = parentsOf.get(n.id) || [];
            if (parents.length === 0) {
                level.set(n.id, maxDepth - longestToLeaf.get(n.id));
                queue.push(n.id);
            }
        });

        while (queue.length) {
            const id = queue.shift();
            for (const c of childrenOf.get(id) || []) {
                if (level.has(c)) continue;
                const parents = parentsOf.get(c) || [];
                if (!parents.every((p) => level.has(p))) continue;
                const lv = Math.max(...parents.map((p) => level.get(p))) + 1;
                level.set(c, lv);
                queue.push(c);
            }
        }
        state.nodes.forEach((n) => {
            if (!level.has(n.id)) level.set(n.id, 0);
        });

        // ── Pass 3: group by level + barycenter sort to reduce crossings ─────
        const byLevel = {};
        state.nodes.forEach((n) => {
            const lv = level.get(n.id);
            (byLevel[lv] = byLevel[lv] || []).push(n);
        });

        const sortedLevels = Object.keys(byLevel)
            .map(Number)
            .sort((a, b) => a - b);

        const orderInLevel = new Map();
        sortedLevels.forEach((lv, idx) => {
            const nodes = byLevel[lv];
            if (idx === 0) {
                nodes.sort((a, b) => (a.name || "").localeCompare(b.name || ""));
            } else {
                nodes.sort((a, b) => {
                    const pa = (parentsOf.get(a.id) || []).filter((p) => orderInLevel.has(p));
                    const pb = (parentsOf.get(b.id) || []).filter((p) => orderInLevel.has(p));
                    const ba = pa.length
                        ? pa.reduce((s, p) => s + orderInLevel.get(p), 0) / pa.length
                        : 0;
                    const bb = pb.length
                        ? pb.reduce((s, p) => s + orderInLevel.get(p), 0) / pb.length
                        : 0;
                    return ba - bb;
                });
            }
            nodes.forEach((n, i) => orderInLevel.set(n.id, i));
        });

        // ── Pass 4: assign x / y, centring each row under the widest one ─────
        const levelHeight = Constants.LEVEL_HEIGHT;
        const colSpacing  = Constants.NODE_HORIZONTAL_SPACING;
        const layout = {};
        const baseX = 200;

        const maxRowSize = Math.max(...Object.values(byLevel).map((arr) => arr.length));
        const widestWidth = (maxRowSize - 1) * colSpacing;

        sortedLevels.forEach((lv) => {
            const nodes = byLevel[lv];
            const rowWidth = (nodes.length - 1) * colSpacing;
            const rowStartCx = baseX + (widestWidth - rowWidth) / 2;
            nodes.forEach((node, i) => {
                const geo = Geometry.nodeGeometry(node);
                const cx = rowStartCx + i * colSpacing;
                const x  = cx - geo.cx;
                const y  = 100 + lv * levelHeight;
                layout[node.id.toString()] = { x, y };
            });
        });

        return layout;
    },
};
