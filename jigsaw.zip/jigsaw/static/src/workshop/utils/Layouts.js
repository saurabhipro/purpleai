/** @odoo-module **/

import { Constants } from "./Constants";
import { Geometry } from "./Geometry";

/**
 * Graph layouts for the PurpleMaps workshop.
 *
 * Modes:
 *  – default       — balanced layered (Sugiyama-style, roots “float” to reduce height)
 *  – hierarchical  — top-down org chart: parents centered over children; orthogonal edges
 *  – circular      — concentric rings by depth
 *  – sales         — same tree positions as hierarchical; maroon card + donut styling
 */

function buildAdjacency(state) {
    const childrenOf = new Map();
    const parentsOf = new Map();
    state.nodes.forEach((n) => {
        childrenOf.set(n.id, []);
        parentsOf.set(n.id, []);
    });
    state.links.forEach((l) => {
        const s = Number(l.source);
        const t = Number(l.target);
        if (Number.isFinite(s) && Number.isFinite(t) && childrenOf.has(s) && parentsOf.has(t)) {
            childrenOf.get(s).push(t);
            parentsOf.get(t).push(s);
        }
    });
    return { childrenOf, parentsOf };
}

/** Barycentric ordering within each level (reduces crossings). */
function finalizeRows(state, level, childrenOf, parentsOf) {
    const byLevel = {};
    state.nodes.forEach((n) => {
        const lv = level.get(n.id);
        (byLevel[lv] = byLevel[lv] || []).push(n);
    });

    const sortedLevels = Object.keys(byLevel)
        .map(Number)
        .sort((a, b) => a - b);

    const orderInLevel = new Map();
    sortedLevels.forEach((lv, idx) => {
        const nodes = byLevel[lv];
        if (idx === 0) {
            nodes.sort((a, b) => (a.name || "").localeCompare(b.name || ""));
        } else {
            nodes.sort((a, b) => {
                const pa = (parentsOf.get(a.id) || []).filter((p) => orderInLevel.has(p));
                const pb = (parentsOf.get(b.id) || []).filter((p) => orderInLevel.has(p));
                const ba = pa.length
                    ? pa.reduce((s, p) => s + orderInLevel.get(p), 0) / pa.length
                    : 0;
                const bb = pb.length
                    ? pb.reduce((s, p) => s + orderInLevel.get(p), 0) / pb.length
                    : 0;
                return ba - bb;
            });
        }
        nodes.forEach((n, i) => orderInLevel.set(n.id, i));
    });

    const levelHeight = Constants.LEVEL_HEIGHT;
    const colSpacing = Constants.NODE_HORIZONTAL_SPACING;
    const layout = {};
    const baseX = 200;

    const rows = Object.values(byLevel);
    const maxRowSize = Math.max(1, ...rows.map((arr) => arr.length));
    const widestWidth = (maxRowSize - 1) * colSpacing;

    sortedLevels.forEach((lv) => {
        const nodes = byLevel[lv];
        const rowWidth = (nodes.length - 1) * colSpacing;
        const rowStartCx = baseX + (widestWidth - rowWidth) / 2;
        nodes.forEach((node, i) => {
            const geo = Geometry.nodeGeometry(node);
            const cx = rowStartCx + i * colSpacing;
            const x = cx - geo.cx;
            const y = 100 + lv * levelHeight;
            layout[node.id.toString()] = { x, y };
        });
    });

    return layout;
}

/** Strict layers: root = 0, child = max(parents) + 1. */
function hierarchicalLevels(state, childrenOf, parentsOf) {
    const level = new Map();
    const queue = [];
    state.nodes.forEach((n) => {
        const parents = parentsOf.get(n.id) || [];
        if (parents.length === 0) {
            level.set(n.id, 0);
            queue.push(n.id);
        }
    });
    if (queue.length === 0) {
        state.nodes.forEach((n) => level.set(n.id, 0));
        return level;
    }
    let head = 0;
    while (head < queue.length) {
        const id = queue[head++];
        for (const c of childrenOf.get(id) || []) {
            const parents = parentsOf.get(c) || [];
            if (!parents.every((p) => level.has(p))) continue;
            const lv = Math.max(...parents.map((p) => level.get(p))) + 1;
            if (!level.has(c)) {
                level.set(c, lv);
                queue.push(c);
            }
        }
    }
    state.nodes.forEach((n) => {
        if (!level.has(n.id)) level.set(n.id, 0);
    });
    return level;
}

function buildByLevel(state, level) {
    const byLevel = {};
    state.nodes.forEach((n) => {
        const lv = level.get(n.id);
        (byLevel[lv] = byLevel[lv] || []).push(n);
    });
    const sortedLevels = Object.keys(byLevel)
        .map(Number)
        .sort((a, b) => a - b);
    return { byLevel, sortedLevels };
}

/** For DAGs: one "layout parent" per node (lowest id) so each node hangs under a single branch. */
function primaryParentId(childId, parentsOf) {
    const ps = parentsOf.get(childId) || [];
    if (!ps.length) return null;
    return Math.min(...ps);
}

function orderedTreeChildren(parentId, childrenOf, parentsOf, level, state) {
    const plv = level.get(parentId);
    return (childrenOf.get(parentId) || [])
        .filter(
            (cid) =>
                primaryParentId(cid, parentsOf) === parentId &&
                level.get(cid) === plv + 1
        )
        .sort((a, b) => {
            const na = state.nodes.find((n) => n.id === a);
            const nb = state.nodes.find((n) => n.id === b);
            return (na?.name || "").localeCompare(nb?.name || "");
        });
}

/**
 * Top-down org-chart: each parent centered over its children, rows spaced by tallest node + gap.
 * (Balanced / "default" mode keeps the older band layout via finalizeRows.)
 */
function finalizeRowsOrgChart(state, level, childrenOf, parentsOf, layoutStyle) {
    const { byLevel, sortedLevels } = buildByLevel(state, level);
    const ROW_GAP = Constants.HIERARCHICAL_ROW_GAP;
    const SUB_GAP = Constants.HIERARCHICAL_SUBTREE_GAP;
    const ROOT_GAP = Constants.HIERARCHICAL_ROOT_GAP;

    const levelTopY = new Map();
    let yCursor = 80;
    for (const lv of sortedLevels) {
        levelTopY.set(lv, yCursor);
        const rowNodes = byLevel[lv];
        const rowH = Math.max(72, ...rowNodes.map((n) => Geometry.nodeGeometry(n, layoutStyle).h));
        yCursor += rowH + ROW_GAP;
    }

    const layout = {};

    function assignSubtree(nodeId, leftX) {
        const node = state.nodes.find((n) => n.id === nodeId);
        if (!node) return { left: leftX, right: leftX };
        const geo = Geometry.nodeGeometry(node, layoutStyle);
        const lv = level.get(nodeId);
        const topY = levelTopY.get(lv);
        const kids = orderedTreeChildren(nodeId, childrenOf, parentsOf, level, state);

        if (!kids.length) {
            layout[String(nodeId)] = { x: leftX, y: topY };
            return { left: leftX, right: leftX + geo.w };
        }

        let curX = leftX;
        const bounds = [];
        for (const cid of kids) {
            const b = assignSubtree(cid, curX);
            bounds.push(b);
            curX = b.right + SUB_GAP;
        }
        const cL = bounds[0].left;
        const cR = bounds[bounds.length - 1].right;
        const mid = (cL + cR) / 2;
        const px = mid - geo.cx;
        layout[String(nodeId)] = { x: px, y: topY };
        const pR = px + geo.w;
        return {
            left: Math.min(cL, px),
            right: Math.max(cR, pR),
        };
    }

    const roots = state.nodes
        .filter((n) => !(parentsOf.get(n.id) || []).length)
        .sort((a, b) => (a.name || "").localeCompare(b.name || ""));

    if (!roots.length) {
        return finalizeRows(state, level, childrenOf, parentsOf);
    }

    let cursorX = 120;
    for (const r of roots) {
        const b = assignSubtree(r.id, cursorX);
        cursorX = b.right + ROOT_GAP;
    }

    const missing = state.nodes.filter((n) => layout[String(n.id)] === undefined);
    if (missing.length) {
        for (const n of missing.sort((a, b) => (a.name || "").localeCompare(b.name || ""))) {
            const geo = Geometry.nodeGeometry(n, layoutStyle);
            const lv = level.get(n.id);
            const topY = levelTopY.get(lv);
            layout[String(n.id)] = { x: cursorX, y: topY };
            cursorX += geo.w + SUB_GAP;
        }
    }

    return layout;
}

export const Layouts = {
    /**
     * Balanced layered layout (original PurpleMaps behaviour).
     */
    treeLayout(state) {
        if (!state.nodes || state.nodes.length === 0) return {};

        const { childrenOf, parentsOf } = buildAdjacency(state);

        const longestToLeaf = new Map();
        const onStack = new Set();
        const computeLongest = (id) => {
            if (longestToLeaf.has(id)) return longestToLeaf.get(id);
            if (onStack.has(id)) return 0;
            onStack.add(id);
            let depth = 0;
            for (const c of childrenOf.get(id) || []) {
                depth = Math.max(depth, 1 + computeLongest(c));
            }
            onStack.delete(id);
            longestToLeaf.set(id, depth);
            return depth;
        };
        state.nodes.forEach((n) => computeLongest(n.id));

        const maxDepth = Math.max(0, ...longestToLeaf.values());

        const level = new Map();
        const queue = [];
        state.nodes.forEach((n) => {
            const parents = parentsOf.get(n.id) || [];
            if (parents.length === 0) {
                level.set(n.id, maxDepth - longestToLeaf.get(n.id));
                queue.push(n.id);
            }
        });

        while (queue.length) {
            const id = queue.shift();
            for (const c of childrenOf.get(id) || []) {
                if (level.has(c)) continue;
                const parents = parentsOf.get(c) || [];
                if (!parents.every((p) => level.has(p))) continue;
                const lv = Math.max(...parents.map((p) => level.get(p))) + 1;
                level.set(c, lv);
                queue.push(c);
            }
        }
        state.nodes.forEach((n) => {
            if (!level.has(n.id)) level.set(n.id, 0);
        });

        return finalizeRows(state, level, childrenOf, parentsOf);
    },

    hierarchicalLayout(state) {
        if (!state.nodes || state.nodes.length === 0) return {};
        const { childrenOf, parentsOf } = buildAdjacency(state);
        const level = hierarchicalLevels(state, childrenOf, parentsOf);
        return finalizeRowsOrgChart(state, level, childrenOf, parentsOf, "hierarchical");
    },

    /** Same org-chart coordinates as hierarchical; nodes render as Sales infographic cards. */
    salesLayout(state) {
        if (!state.nodes || state.nodes.length === 0) return {};
        const { childrenOf, parentsOf } = buildAdjacency(state);
        const level = hierarchicalLevels(state, childrenOf, parentsOf);
        return finalizeRowsOrgChart(state, level, childrenOf, parentsOf, "sales");
    },

    /** Same row placement as hierarchical; used with orthogonal edge routing. */
    orthogonalGridLayout(state) {
        return Layouts.hierarchicalLayout(state);
    },

    circularLayout(state) {
        if (!state.nodes || state.nodes.length === 0) return {};
        const { childrenOf, parentsOf } = buildAdjacency(state);
        const level = hierarchicalLevels(state, childrenOf, parentsOf);

        const byLevel = {};
        state.nodes.forEach((n) => {
            const lv = level.get(n.id);
            (byLevel[lv] = byLevel[lv] || []).push(n);
        });
        const sortedLevels = Object.keys(byLevel)
            .map(Number)
            .sort((a, b) => a - b);

        sortedLevels.forEach((lv) => {
            byLevel[lv].sort((a, b) => (a.name || "").localeCompare(b.name || ""));
        });

        const layout = {};
        const centerX = 550;
        const centerY = 480;
        const ringBase = 200;
        const ringStep = 280;

        sortedLevels.forEach((lv, ringIdx) => {
            const nodes = byLevel[lv];
            const n = Math.max(nodes.length, 1);
            const R = ringBase + ringIdx * ringStep;
            nodes.forEach((node, i) => {
                const angle = (2 * Math.PI * i) / n - Math.PI / 2;
                const cx = centerX + R * Math.cos(angle);
                const cy = centerY + R * Math.sin(angle);
                const geo = Geometry.nodeGeometry(node);
                layout[node.id.toString()] = {
                    x: cx - geo.cx,
                    y: cy - geo.cy,
                };
            });
        });

        return layout;
    },

    compute(state, mode) {
        switch (mode) {
            case "hierarchical":
                return Layouts.hierarchicalLayout(state);
            case "circular":
                return Layouts.circularLayout(state);
            case "orthogonal":
                return Layouts.orthogonalGridLayout(state);
            case "sales":
                return Layouts.salesLayout(state);
            default:
                return Layouts.treeLayout(state);
        }
    },
};
