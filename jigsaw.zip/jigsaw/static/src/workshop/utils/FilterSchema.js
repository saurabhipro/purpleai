/** @odoo-module **/

/**
 * FilterSchema — declares filterable fields grouped by category for the
 * PurpleMaps workshop advanced filter.
 *
 * Each category may have:
 *   icon:     Font Awesome 4 glyph name without the `fa-` prefix (e.g. `building`)
 *
 * Each field has:
 *   key:      payload key on a node returned by `get_diagram_data`
 *   label:    user-facing label
 *   type:     'text' | 'number' | 'date' | 'selection' | 'boolean'
 *   options:  for 'selection', list of { value, label }
 */

const sel = (value, label) => ({ value, label });

export const FilterSchema = {
    categories: [
        {
            key: "entity_basics",
            label: "Entity Basics",
            icon: "building",
            fields: [
                { key: "pe_entity_type", label: "PE Entity Type", type: "selection", options: [
                    sel("portfolio_co", "Portfolio Co"), sel("spv", "SPV"), sel("fund_entity", "Fund"),
                    sel("gp", "GP"), sel("lp", "LP"), sel("subsidiary", "Subsidiary"),
                ]},
                { key: "type", label: "Shape Type", type: "selection", options: [
                    sel("individual", "Individual"), sel("company", "Company"), sel("trust", "Trust"),
                    sel("fund", "Fund"), sel("gov", "Government"), sel("org_unit", "Organization Unit"),
                    sel("asset", "Asset"), sel("account", "Account"),
                ]},
                { key: "pe_jurisdiction", label: "PE Jurisdiction", type: "selection", options: [
                    sel("india", "India"), sel("singapore", "Singapore"),
                    sel("delaware", "Delaware"), sel("other", "Other"),
                ]},
                { key: "jurisdiction", label: "Jurisdiction (Free Text)", type: "text" },
                { key: "pe_industry", label: "Industry / Sector", type: "selection", options: [
                    sel("saas", "SaaS"), sel("fintech", "Fintech"), sel("healthtech", "Healthtech"),
                    sel("edtech", "Edtech"), sel("ecommerce", "E-commerce"),
                    sel("manufacturing", "Manufacturing"), sel("other", "Other"),
                ]},
                { key: "pe_stage", label: "Stage", type: "selection", options: [
                    sel("seed", "Seed"), sel("series_a", "Series A"), sel("series_b", "Series B"),
                    sel("growth", "Growth"), sel("pre_ipo", "Pre-IPO"),
                ]},
                { key: "pe_status", label: "Status", type: "selection", options: [
                    sel("active", "Active"), sel("exited", "Exited"),
                    sel("winding_up", "Winding Up"), sel("dormant", "Dormant"),
                ]},
            ],
        },
        {
            key: "investment",
            label: "Investment & Ownership",
            icon: "line-chart",
            fields: [
                { key: "investment_date", label: "Investment Date", type: "date" },
                { key: "investment_round", label: "Investment Round", type: "selection", options: [
                    sel("seed", "Seed"), sel("series_a", "Series A"),
                    sel("series_b", "Series B"), sel("bridge", "Bridge"),
                ]},
                { key: "ownership_pct_overall", label: "Ownership %", type: "number" },
                { key: "amount_invested", label: "Amount Invested", type: "number" },
                { key: "valuation_current", label: "Current Valuation", type: "number" },
                { key: "valuation_last", label: "Last Valuation", type: "number" },
                { key: "performance_irr", label: "IRR %", type: "number" },
                { key: "performance_moic", label: "MOIC (x)", type: "number" },
                { key: "investor_type", label: "Investor Type", type: "selection", options: [
                    sel("lead", "Lead"), sel("co_investor", "Co-investor"),
                ]},
                { key: "spv_linked", label: "SPV Linked", type: "boolean" },
            ],
        },
        {
            key: "performance",
            label: "Portfolio Performance",
            icon: "bar-chart",
            fields: [
                { key: "revenue_band", label: "Revenue Band", type: "selection", options: [
                    sel("lt_1m", "< $1M"), sel("1m_10m", "$1M – $10M"), sel("gt_10m", "$10M+"),
                ]},
                { key: "burn_rate", label: "Monthly Burn Rate", type: "number" },
                { key: "runway_months", label: "Runway (months)", type: "number" },
                { key: "profitability", label: "Profitability", type: "selection", options: [
                    sel("profitable", "Profitable"), sel("loss_making", "Loss-making"),
                ]},
                { key: "high_growth_flag", label: "High Growth", type: "boolean" },
                { key: "exit_pipeline", label: "Exit Pipeline", type: "selection", options: [
                    sel("exit_12m", "Exit in 12 months"), sel("exit_24m", "Exit in 24 months"),
                    sel("none", "No active pipeline"),
                ]},
            ],
        },
        {
            key: "compliance",
            label: "Compliance & Governance",
            icon: "shield",
            fields: [
                { key: "compliance_status", label: "Compliance Status", type: "selection", options: [
                    sel("green", "Green"), sel("amber", "Amber"), sel("red", "Red"),
                ]},
                { key: "board_meetings", label: "Board Meetings Held", type: "boolean" },
                { key: "board_meeting_frequency", label: "Board Meeting Frequency", type: "selection", options: [
                    sel("monthly", "Monthly"), sel("quarterly", "Quarterly"), sel("annually", "Annually"),
                ]},
                { key: "financial_filings", label: "Financial Filings Up To Date", type: "boolean" },
                { key: "roc_sec_status", label: "ROC / SEC Status", type: "selection", options: [
                    sel("filed", "Filed"), sel("pending", "Pending"),
                ]},
                { key: "kyc_aml", label: "KYC / AML", type: "selection", options: [
                    sel("complete", "Complete"), sel("pending", "Pending"),
                ]},
                { key: "document_completeness", label: "Document Completeness", type: "selection", options: [
                    sel("complete", "Complete"), sel("partial", "Partial"), sel("missing", "Missing"),
                ]},
                { key: "regulatory_flag_fema", label: "FEMA Flag", type: "boolean" },
                { key: "regulatory_flag_odi", label: "ODI Flag", type: "boolean" },
                { key: "regulatory_flag_fdi", label: "FDI Flag", type: "boolean" },
            ],
        },
        {
            key: "captable",
            label: "Cap Table & Securities",
            icon: "pie-chart",
            fields: [
                { key: "share_class", label: "Share Class", type: "selection", options: [
                    sel("equity", "Equity"), sel("preference", "Preference"), sel("safe", "SAFE"),
                ]},
                { key: "esop_pct", label: "ESOP %", type: "number" },
                { key: "last_round_dilution", label: "Last Round Dilution %", type: "number" },
                { key: "liquidation_preference", label: "Liquidation Preference", type: "selection", options: [
                    sel("1x", "1x"), sel("2x", "2x"), sel("3x", "3x"),
                    sel("participating", "Participating"), sel("non_participating", "Non-Participating"),
                ]},
                { key: "anti_dilution", label: "Anti-dilution", type: "boolean" },
            ],
        },
        {
            key: "stakeholders",
            label: "Stakeholders",
            icon: "users",
            fields: [
                { key: "board_seat", label: "Board Seat", type: "boolean" },
                { key: "observer_rights", label: "Observer Rights", type: "boolean" },
                { key: "founder_status", label: "Founder Status", type: "selection", options: [
                    sel("active", "Active"), sel("exited", "Exited"),
                ]},
                { key: "management_changes", label: "Management Changes", type: "boolean" },
                { key: "co_investors", label: "Co-investors", type: "boolean" },
            ],
        },
        {
            key: "timeline",
            label: "Timeline",
            icon: "calendar",
            fields: [
                { key: "next_board_meeting", label: "Next Board Meeting", type: "date" },
                { key: "last_valuation_date", label: "Last Valuation Date", type: "date" },
                { key: "exit_timeline_estimate", label: "Exit Timeline Estimate", type: "text" },
            ],
        },
        {
            key: "documents",
            label: "Documents",
            icon: "folder-open",
            fields: [
                { key: "documents_uploaded", label: "Documents Uploaded", type: "selection", options: [
                    sel("complete", "Complete"), sel("partial", "Partial"), sel("missing", "Missing"),
                ]},
                { key: "latest_financials", label: "Latest Financials Available", type: "boolean" },
                { key: "sha_ssa", label: "SHA / SSA", type: "selection", options: [
                    sel("signed", "Signed"), sel("not_signed", "Not Signed"),
                ]},
                { key: "due_diligence", label: "Due Diligence", type: "selection", options: [
                    sel("pending", "Pending"), sel("completed", "Completed"),
                ]},
            ],
        },
        {
            key: "fund",
            label: "Fund Structuring",
            icon: "university",
            fields: [
                { key: "fund_name", label: "Fund Name", type: "text" },
                { key: "gp_lp_mapping", label: "GP / LP Mapping", type: "boolean" },
                { key: "co_investment", label: "Co-investment", type: "boolean" },
                { key: "spv_vs_direct", label: "SPV vs Direct", type: "selection", options: [
                    sel("spv", "SPV"), sel("direct", "Direct"),
                ]},
                { key: "cross_holdings", label: "Cross Holdings", type: "boolean" },
            ],
        },
        {
            key: "risk",
            label: "Risk & Alerts",
            icon: "exclamation-triangle",
            fields: [
                { key: "risk_high_burn", label: "High Burn", type: "boolean" },
                { key: "risk_down_round", label: "Down Round Risk", type: "boolean" },
                { key: "risk_founder_dispute", label: "Founder Dispute", type: "boolean" },
                { key: "risk_compliance_breach", label: "Compliance Breach", type: "boolean" },
                { key: "risk_regulatory_exposure", label: "Regulatory Exposure", type: "boolean" },
            ],
        },
        {
            key: "tags",
            label: "Tags",
            icon: "tags",
            fields: [
                { key: "tag_top_10", label: "Top 10 Bets", type: "boolean" },
                { key: "tag_followon_priority", label: "Follow-on Priority", type: "boolean" },
                { key: "tag_under_watch", label: "Under Watch", type: "boolean" },
                { key: "tag_exit_ready", label: "Exit Ready", type: "boolean" },
                { key: "tag_strategic_focus", label: "Strategic Focus", type: "boolean" },
            ],
        },
    ],

    findCategory(key) {
        return this.categories.find((c) => c.key === key) || null;
    },

    findField(categoryKey, fieldKey) {
        const cat = this.findCategory(categoryKey);
        if (!cat) return null;
        return cat.fields.find((f) => f.key === fieldKey) || null;
    },

    operatorsFor(type) {
        switch (type) {
            case "text":
                return [
                    { value: "contains", label: "contains" },
                    { value: "ncontains", label: "does not contain" },
                    { value: "is", label: "is" },
                    { value: "isnot", label: "is not" },
                    { value: "set", label: "is set" },
                    { value: "notset", label: "is not set" },
                ];
            case "number":
                return [
                    { value: "eq", label: "=" },
                    { value: "ne", label: "≠" },
                    { value: "gt", label: ">" },
                    { value: "gte", label: "≥" },
                    { value: "lt", label: "<" },
                    { value: "lte", label: "≤" },
                    { value: "set", label: "is set" },
                    { value: "notset", label: "is not set" },
                ];
            case "date":
                return [
                    { value: "is", label: "on" },
                    { value: "before", label: "before" },
                    { value: "after", label: "after" },
                    { value: "set", label: "is set" },
                    { value: "notset", label: "is not set" },
                ];
            case "selection":
                return [
                    { value: "is", label: "is" },
                    { value: "isnot", label: "is not" },
                    { value: "set", label: "is set" },
                    { value: "notset", label: "is not set" },
                ];
            case "boolean":
                return [
                    { value: "true", label: "is true" },
                    { value: "false", label: "is false" },
                ];
            default:
                return [];
        }
    },
};
