/** @odoo-module **/

function isSet(value) {
    if (value === undefined || value === null) return false;
    if (typeof value === "string") return value.trim() !== "";
    if (typeof value === "number") return !Number.isNaN(value);
    return !!value;
}

function evalRule(node, rule) {
    const raw = node[rule.field];
    const op = rule.operator;

    if (op === "set") return isSet(raw);
    if (op === "notset") return !isSet(raw);

    switch (rule.type) {
        case "boolean":
            return op === "true" ? !!raw : !raw;

        case "number": {
            const a = parseFloat(raw);
            const b = parseFloat(rule.value);
            if (Number.isNaN(a) || Number.isNaN(b)) return false;
            switch (op) {
                case "eq":  return a === b;
                case "ne":  return a !== b;
                case "gt":  return a >  b;
                case "gte": return a >= b;
                case "lt":  return a <  b;
                case "lte": return a <= b;
                default:    return false;
            }
        }

        case "date": {
            const a = raw ? new Date(raw).getTime() : NaN;
            const b = rule.value ? new Date(rule.value).getTime() : NaN;
            if (Number.isNaN(a) || Number.isNaN(b)) return false;
            switch (op) {
                case "is":     return Math.floor(a / 86400000) === Math.floor(b / 86400000);
                case "before": return a <  b;
                case "after":  return a >  b;
                default:       return false;
            }
        }

        case "selection": {
            const target = (rule.value || "").toString();
            if (!target) return false;
            if (op === "is")    return raw === target;
            if (op === "isnot") return raw !== target;
            return false;
        }

        case "text":
        default: {
            const a = (raw || "").toString().toLowerCase();
            const b = (rule.value || "").toString().toLowerCase();
            switch (op) {
                case "contains":  return b !== "" && a.includes(b);
                case "ncontains": return b !== "" && !a.includes(b);
                case "is":        return a === b;
                case "isnot":     return a !== b;
                default:          return false;
            }
        }
    }
}

function hasActiveRules(state) {
    return Array.isArray(state.filterRules) && state.filterRules.some((r) => r && r.enabled !== false && r.field);
}

export const Filtering = {
    isNodeFilteredOut(node, state) {
        const ownershipActive = state.ownershipVisibleNodeIds && state.ownershipVisibleNodeIds.length > 0;
        const rulesActive = hasActiveRules(state);

        if (!state.filterText && !state.filterType && !ownershipActive && !rulesActive) return false;

        let match = true;

        if (state.filterText) {
            const search = state.filterText.toLowerCase();
            const nMatch = (node.name || '').toLowerCase().includes(search);
            const jMatch = (node.jurisdiction || '').toLowerCase().includes(search);
            if (!nMatch && !jMatch) match = false;
        }

        if (state.filterType) {
            if (node.type !== state.filterType) match = false;
        }

        if (ownershipActive) {
            if (!state.ownershipVisibleNodeIds.includes(node.id)) match = false;
        }

        if (rulesActive) {
            const mode = state.filterRulesMode || "all"; // 'all' (AND) | 'any' (OR)
            const rules = state.filterRules.filter((r) => r && r.enabled !== false && r.field);
            const ok = mode === "any"
                ? rules.some((r) => evalRule(node, r))
                : rules.every((r) => evalRule(node, r));
            if (!ok) match = false;
        }

        return !match;
    },

    isLinkFilteredOut(link, state) {
        const sourceNode = state.nodes.find(n => n.id === link.source);
        const targetNode = state.nodes.find(n => n.id === link.target);
        if (!sourceNode || !targetNode) return true;
        return this.isNodeFilteredOut(sourceNode, state) || this.isNodeFilteredOut(targetNode, state);
    },

    updateOwnershipFilter(state) {
        if (!state.selectedNodeIds || state.selectedNodeIds.length === 0 || !state.showOwnershipMenu) {
            return [];
        }

        const startNodeId = state.selectedNodeIds[0];
        const visibleIds = new Set([startNodeId]);
        const direction = state.ownershipDirection;
        const usePct = state.ownershipFilterEnabled;
        const threshold = parseFloat(state.ownershipPctThreshold) || 0;
        const type = state.ownershipPctType;

        let toVisit = [startNodeId];

        while (toVisit.length > 0) {
            const currentId = toVisit.shift();

            state.links.forEach(l => {
                let nextId = null;
                let isUp = false;
                let isDown = false;

                if (l.target === currentId) {
                    nextId = l.source;
                    isUp = true;
                } else if (l.source === currentId) {
                    nextId = l.target;
                    isDown = true;
                }

                if (!nextId || visibleIds.has(nextId)) return;

                if (direction === 'up' && !isUp) return;
                if (direction === 'down' && !isDown) return;

                let passPct = true;
                const linkPct = parseFloat(l.percent) || 0;

                if (usePct) {
                    if (type === 'more') {
                        passPct = linkPct >= threshold;
                    } else {
                        passPct = linkPct <= threshold;
                    }
                }

                if (passPct) {
                    visibleIds.add(nextId);
                    toVisit.push(nextId);
                }
            });
        }

        return Array.from(visibleIds);
    }
};
