/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component, onWillStart, useState } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";

/**
 * Jigsaw / PurpleMaps Dashboard
 * Aggregates entity / diagram / relation stats from the backend and renders
 * a single-page overview with KPI cards, distribution bars and a recent-funds list.
 */
export class JigsawDashboard extends Component {
    static template = "jigsaw.Dashboard";
    static components = {};

    setup() {
        this.action = useService("action");
        this.orm = useService("orm");

        this.state = useState({
            loading: true,
            data: null,
            error: null,
        });

        onWillStart(async () => {
            await this.refresh();
        });
    }

    async refresh() {
        this.state.loading = true;
        this.state.error = null;
        try {
            this.state.data = await this.orm.call(
                "jigsaw.diagram",
                "get_dashboard_data",
                [],
            );
        } catch (e) {
            console.error(e);
            this.state.error = (e && e.data && e.data.message) || (e && e.message) || "Failed to load dashboard.";
        } finally {
            this.state.loading = false;
        }
    }

    // ── Open the visualizer for a given diagram id ────────────────
    openDiagram(diagramId) {
        if (!diagramId) return;
        this.action.doAction({
            type: "ir.actions.client",
            tag: "jigsaw.workshop",
            params: { diagram_id: diagramId },
            target: "current",
        });
    }

    openEntity(entityId) {
        if (!entityId) return;
        this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "jigsaw.entity",
            res_id: entityId,
            views: [[false, "form"]],
            target: "current",
        });
    }

    openFundsList() {
        this.action.doAction({
            type: "ir.actions.act_window",
            name: "Funds",
            res_model: "jigsaw.diagram",
            view_mode: "kanban,list,form",
            views: [[false, "kanban"], [false, "list"], [false, "form"]],
            target: "current",
        });
    }

    openEntitiesList(domain = []) {
        this.action.doAction({
            type: "ir.actions.act_window",
            name: "Entities",
            res_model: "jigsaw.entity",
            view_mode: "list,form,kanban",
            views: [[false, "list"], [false, "form"]],
            domain,
            target: "current",
        });
    }

    // ── Helpers for templating ────────────────────────────────────
    fmtCurrency(value) {
        const num = Number(value || 0);
        const sym = (this.state.data && this.state.data.totals.currency_symbol) || "$";
        if (Math.abs(num) >= 1e9) return `${sym}${(num / 1e9).toFixed(2)}B`;
        if (Math.abs(num) >= 1e6) return `${sym}${(num / 1e6).toFixed(2)}M`;
        if (Math.abs(num) >= 1e3) return `${sym}${(num / 1e3).toFixed(1)}K`;
        return `${sym}${num.toFixed(0)}`;
    }

    fmtInt(value) {
        return Number(value || 0).toLocaleString();
    }

    labelize(value) {
        if (!value) return "Unspecified";
        return String(value).replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
    }

    // ── Unified PurpleMaps palette (purple / violet + gold accent) — all chart cards share one family ──
    barColor(_category, index) {
        const scale = [
            "#502D7F",
            "#5c4082",
            "#6b5694",
            "#7d6a9e",
            "#9d90b8",
            "#beb3d1",
            "#c9a44a",
            "#6b5a3d",
        ];
        return scale[index % scale.length];
    }

    /**
     * Simple card breakdown: totals + rows with % and a slim bar (no pie SVG).
     */
    simpleBreakdownModel(rows, category, maxSegments = 8, unitLabel = "records") {
        const raw = [...(rows || [])].filter((r) => (r.count || 0) > 0);
        const total = raw.reduce((s, r) => s + (r.count || 0), 0);
        if (!total) {
            return { total: 0, items: [], unitLabel };
        }
        raw.sort((a, b) => (b.count || 0) - (a.count || 0));
        const top = raw.slice(0, maxSegments);
        const restSum = raw.slice(maxSegments).reduce((s, x) => s + (x.count || 0), 0);
        const segments = top.map((row, i) => ({
            label: this.labelize(row.label),
            count: row.count || 0,
            color: this.barColor(category, i),
        }));
        if (restSum > 0) {
            segments.push({
                label: "Other",
                count: restSum,
                color: "#8675a8",
            });
        }
        const maxCount = Math.max(...segments.map((s) => s.count), 1);
        const items = segments.map((seg) => ({
            label: seg.label,
            count: seg.count,
            color: seg.color,
            pct: Math.round((seg.count / total) * 100),
            barPct: Math.max(4, Math.round((seg.count / maxCount) * 100)),
        }));
        return { total, items, unitLabel };
    }

    riskLabel(key) {
        const m = {
            risk_high_burn:           "High Burn",
            risk_down_round:          "Down Round",
            risk_founder_dispute:     "Founder Dispute",
            risk_compliance_breach:   "Compliance Breach",
            risk_regulatory_exposure: "Regulatory Exposure",
        };
        return m[key] || key;
    }

    tagLabel(key) {
        const m = {
            tag_top_10:            "Top 10 Bets",
            tag_followon_priority: "Follow-on Priority",
            tag_under_watch:       "Under Watch",
            tag_exit_ready:        "Exit Ready",
            tag_strategic_focus:   "Strategic Focus",
        };
        return m[key] || key;
    }

    get riskList() {
        const r = this.state.data && this.state.data.risk_flags;
        if (!r) return [];
        return Object.keys(r).map((k) => ({ key: k, label: this.riskLabel(k), count: r[k] }))
                              .sort((a, b) => b.count - a.count);
    }

    get tagList() {
        const t = this.state.data && this.state.data.tag_counts;
        if (!t) return [];
        return Object.keys(t).map((k) => ({ key: k, label: this.tagLabel(k), count: t[k] }))
                              .sort((a, b) => b.count - a.count);
    }
}

registry.category("actions").add("jigsaw.dashboard", JigsawDashboard);
